(function ($) {
  "use strict";
  
  $(document).on('click', '[data-nav] a', function (e) {
    var $this = $(this), $active, $li, $li_li;

    $li = $this.parent();
    $li_li = $li.parents('li');

    $active = $li.closest( "[data-nav]" ).find('.active');

    $li_li.addClass('active');
    ( $this.next().is('ul') && $li.toggleClass('active') ) || $li.addClass('active');
    
    $active.not($li_li).not($li).removeClass('active');

    if($this.attr('href') && $this.attr('href') !=''){
      $(document).trigger('Nav:changed');
    }
  });
 
  // init the active class when page reload
  function init(){
    var url = window.location.pathname;
    $('#aside .active').removeClass('active');
    $('#aside a').filter( function() {
      var href = typeof $(this).attr('href') != 'undefined' && $(this).attr('href').length > 1 
        ? $(this).attr('href').substr(1) : "";
      return url.includes(href);
    }).parents('li').addClass( 'active' );
  }
  
  init();

  $(document).on('pjaxEnd', function(){
    init();
  });

})(jQuery);
