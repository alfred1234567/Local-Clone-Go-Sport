(function ($) {
	"use strict";

  var colors = ['red', 'pink', 'purple', 'deep-purple', 'indigo', 'blue', 'light-blue', 'cyan', 'teal', 'green', 'light-green', 'lime', 'yellow', 'amber', 'orange', 'deep-orange', 'brown', 'blue-grey', 'grey'];

  var init = function(){  
    // Setup - add a text input to each footer cell
    $('#datatable thead tr').clone(true).appendTo( '#datatable thead' );
    $('#datatable thead tr:eq(1) th:not(:first-child, :last-child)').each( function (i) {
      var title = $(this).text();
      $(this).html( '<input type="text" class="form-control" placeholder="Search '+title+'" />' );

      // Apply the filter
      $("#datatable thead input").on( 'keyup change', function () {
        table
            .api()
            .column( $(this).parent().index()+':visible' )
            .search( this.value )
            .draw();
      });
    });

    var table = $('#datatable').dataTable({
      orderCellsTop: true,
      fixedHeader: true,
      colReorder: true
    });
  }

  // for ajax to init again
  $.fn.dataTable.init = init;

})(jQuery);
