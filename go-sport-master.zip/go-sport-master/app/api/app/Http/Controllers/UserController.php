<?php

namespace App\Http\Controllers;

use Hash;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return view('modules.user.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('modules.user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'role' => 'required|integer|in:1,3',
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'user_id' => 'required|unique:users',
            'password' => 'required|min:5',
        ]);

        try
        {
            \DB::beginTransaction();

            User::create([
                'role_id' => $request->input('role'),
                'name' => $request->input('name'),
                'email' => $request->input('email'),
                'password' => Hash::make($request->input('password')),
                'user_id' => $request->input('user_id'),
            ]);

            \DB::commit();

            return back()->with(['success' => 'Insert success']);
        }
        catch (\Exception $e)
        {
            \DB::rollback();

            return back()->with([
                'error' => 'Failed to insert with exception: ' . $e,
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($user = User::find($id))
            return view('modules.user.edit', compact('user'));
        
        return back()->with(['error' => 'User not found']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'role' => 'required|integer|in:1,3',
            'name' => 'required|string',
            'email' => 'required|email|unique:users,email,' . $id . ',id,deleted_at,NULL',
            'password' => !empty($request->input('password')) ? 'required' : '',
            'user_id' => 'required|unique:users,user_id,' . $id . ',id,deleted_at,NULL',
        ]);

        try
        {
            \DB::beginTransaction();

            if ($user = User::find($id))
            {
                $user->update([
                    'role_id' => $request->input('role'),
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'password' => Hash::make($request->input('password')),
                    'user_id' => $request->input('user_id'),
                ]);

                \DB::commit();

                return back()->with(['success' => 'Update success']);
            }
        }
        catch (\Exception $e)
        {
            \DB::rollback();

            return back()->with([
                'error' => 'Failed to update with exception: ' . $e,
            ]);
        }
    }
    
    public function delete($id)
    {
        if ($user = User::find($id))
        {
            $user->delete();

            return back()->with(['success' => 'Delete success']);
        }

        return back()->with([
            'error' => 'Failed to delete data'
        ]);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function view($id)
    {
        if ($user = User::find($id))
        {
            return view('modules.user.detail', compact('user'));
        }

        return back()->with([
            'error' => 'Data not found'
        ]);
    }
}
