<?php

namespace App\Http\Controllers;

use Storage;
use App\Slider;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sliders = Slider::orderBy('created_at', 'desc')->get();
        return view('modules.slider.index', compact('sliders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('modules.slider.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'img' => 'required',
        ]);

        $fileName = null;

        try
        {
            \DB::beginTransaction();

            $img = $request->file('img');
            $fileName = pathinfo($img->getClientOriginalName(), PATHINFO_FILENAME) . '-slider-' . time() . '.' . $img->getClientOriginalExtension();
            Storage::put('public/images/sliders/' . $fileName, file_get_contents($img));

            Slider::create([
                'file' => $fileName,
            ]);

            \DB::commit();

            return back()->with(['success' => 'Insert success']);
        }
        catch (\Exception $e)
        {
            \DB::rollback();

            return back()->with([
                'error' => 'Failed to upload with exception; ' . $e,
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if ($slider = Slider::find($id))
            return view('modules.slider.edit', compact('slider'));
        
        return back()->with(['error' => 'Data not found']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'img' => 'required',
        ]);

        $fileName = null;

        try
        {
            \DB::beginTransaction();

            if ($slider = Slider::find($id))
            {
                $img = $request->file('img');
                $fileName = pathinfo($img->getClientOriginalName(), PATHINFO_FILENAME) . '-slider-' . time() . '.' . $img->getClientOriginalExtension();
                Storage::put('public/images/sliders/' . $fileName, file_get_contents($img));

                $slider->update([
                    'file' => $fileName,
                ]);

                \DB::commit();

                return back()->with(['success' => 'Update success']);
            }
        }
        catch (\Exception $e)
        {
            \DB::rollback();

            return back()->with([
                'error' => 'Failed to update slider with exception; ' . $e,
            ]);
        }
    }
    
    public function delete($id)
    {
        if ($slider = Slider::find($id))
        {
            $slider->delete();

            return back()->with(['success' => 'Delete success']);
        }

        return back()->with([
            'error' => 'Failed to delete data'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
