<?php

namespace App\Http\Controllers\API;

use App\Slider;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SliderController extends Controller
{
    public function all()
    {
        $sliders = Slider::all('id', 'file');
        return response()->json([
            'success' => [
                'sliders' => $sliders,
            ]
        ], 200);
    }
}
