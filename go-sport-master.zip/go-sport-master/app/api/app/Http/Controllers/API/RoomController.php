<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Room;

class RoomController extends Controller
{
    public function getDetails($id)
    {
        $room = Room::find($id);
        return response()->json([
            'success' => [
                'room' => $room,
            ]
        ], 200);
    }

    public function join(Request $request, $id)
    {
        $input = json_decode($request->getContent(), true);
        $room = Room::find($id);
        $room->players = $input['players'];
        $room->save();
        return response()->json([
            'success' => [
                'room' => $room,
            ]
        ], 200);
    }
}
