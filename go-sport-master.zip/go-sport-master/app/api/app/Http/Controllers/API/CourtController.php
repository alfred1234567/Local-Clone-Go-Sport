<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use App\Court;
use App\CourtPhoto;
use App\Room;

class CourtController extends Controller
{
    public function getDetails($id)
    {
        $court = Court::where('id', $id)
            ->with('photos:court_id,title,caption,file')
            ->with('rooms:court_id,id,dt,duration,slot,paid')
            ->select('id', 'price')
            ->first();
        return response()->json([
            'success' => [
                'court' => $court,
            ]
        ], 200);
    }

    public function createRoom(Request $request, $id)
    {
        $input = json_decode($request->getContent(), true);
        $validator = Validator::make($input, [
            "dt" => "required|string",
            "duration" => "required|integer",
            "court_number" => "required|integer",
            "slot" => "required|integer",
            "level" => "required|string",
            "gender" => "required|string",
            "min_age" => "required|integer",
            "max_age" => "required|integer",
        ]);

        if ($validator->fails())
        {
            return response()->json([
                'error' => [
                    'message' => implode(',', $validator->messages()->all()),
                    'status_code' => 200,
                ]
            ], 200);
        } else {
            $input["court_id"] = $id;
            $room = Room::create($input);
            $success['room'] = $room;

            return response()->json(['success' => $success], 200);
        }
    }
}
