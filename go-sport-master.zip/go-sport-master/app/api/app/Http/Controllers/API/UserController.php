<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Validator;
use App\User;

class UserController extends Controller
{
    public function login(Request $request)
    {
        $input = json_decode($request->getContent(), true);
        if (Auth::attempt(['user_id' => $input['user_id'], 'password' => $input['password']]))
        {
            $user = Auth::user();
            $success['user'] = $user;
            return response()->json(['success' => $success], 200);
        }
        else
        {
            return response()->json([
                'error' => [
                    'message' => 'Invalid login credentials',
                    'status_code' => 401,
                ]
            ], 401);
        }
    }

    public function register(Request $request)
    {
        $input = json_decode($request->getContent(), true);
        $validator = Validator::make($input, [
            "user_id" => "required|unique:users",
            "email" => "required|unique:users",
            "phone" => "required|string",
            "gender" => "required|in:male,female",
            "age" => "required|integer",
        ]);

        if ($validator->fails())
        {
            return response()->json([
                'error' => [
                    'message' => implode(',', $validator->messages()->all()),
                    'status_code' => 200,
                ]
            ], 200);
        } else {
            $input['password'] = bcrypt($input['password']);
            $user = User::create($input);
            $success['user'] = $user;

            return response()->json(['success' => $success], 200);
        }
    }

    public function details()
    {
        $user = Auth::user();
        return response()->json(['success' => $user], 200);
    }

    public function getProfile($id)
    {
        $user = User::find($id);
        return response()->json(['success' => $user], 200);
    }

    public function editProfile(Request $request, $id)
    {
        $input = json_decode($request->getContent(), true);
        $validator = Validator::make($input, [
            "email" => 'required|email|unique:users,email,' . $id . ',id,deleted_at,NULL',
            "phone" => "required|string",
            "gender" => "required|in:male,female",
            "age" => "required|integer",
        ]);

        if ($validator->fails())
        {
            return response()->json([
                'error' => [
                    'message' => implode(',', $validator->messages()->all()),
                    'status_code' => 200,
                ]
            ], 200);
        } else {
            if ($user = User::find($id))
            {
                $user->name = $input['name'];
                $user->email = $input['email'];
                $user->phone = $input['phone'];
                $user->gender = $input['gender'];
                $user->age = intval($input['age']);
                if (array_key_exists("password", $input))
                {
                    $user->password = \Hash::make($input['password']);
                }
                $user->save();
                $success['user'] = $user;
                return response()->json(['success' => $success], 200);
            }

            return response()->json([
                'error' => [
                    'message' => 'User not found',
                    'status_code' => 401,
                ]
            ], 401);
        }
    }
}
