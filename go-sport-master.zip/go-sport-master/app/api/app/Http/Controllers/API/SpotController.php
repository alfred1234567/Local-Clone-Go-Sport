<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Spot;
use App\SpotPhoto;

class SpotController extends Controller
{
    public function getSpotList($categoryId)
    {
        $spots = Spot::where('category_id', $categoryId)
            ->select('id', 'name', 'address', 'price', 'ratings', 'photo')
            ->get();
        return response()->json([
            'success' => [
                'spots' => $spots,
            ]
        ], 200);
    }

    public function getDetails($id)
    {
        $spot = Spot::where('id', $id)
            ->with('photos:spot_id,title,caption,file')
            ->select('id', 'name', 'address', 'price', 'ratings', 'reviews', 'facilities', 'description', 'photo')
            ->first();
        return response()->json([
            'success' => [
                'spot' => $spot,
            ]
        ], 200);
    }

    public function getCourts($id)
    {
        $courts = Spot::find($id)->courts;
        return response()->json([
            'success' => [
                'courts' => $courts,
            ]
        ], 200);
    }
}
