<?php

namespace App\Http\Controllers;

use App\Room;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    public function changeStatus(Request $request, $id)
    {
        if ($request->has('to'))
        {
            $room = Room::find($id);
            $room->paid = intval($request->input('to'));
            if ($room->save())
            {
                return back()->with(['success' => 'Room status has been changed']);
            }
        }

        return back()->with([
            'error' => 'Failed to change room status'
        ]);
    }
}
