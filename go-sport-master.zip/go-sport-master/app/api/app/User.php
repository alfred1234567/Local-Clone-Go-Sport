<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'role_id', 'user_id', 'name', 'email', 'phone', 'gender', 'password', 'age',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function role()
    {
        return $this->belongsTo('App\Role');
    }

    public function spots()
    {
        return $this->hasMany('App\Spot', 'partner_id');
    }

    public function isAdmin()
    {
        if (!$this->has('role'))
        {
            return false;
        }

        return $this->role->id === 1;
    }

    public function isPartner()
    {
        if (!$this->has('role'))
        {
            return false;
        }

        return $this->role->id === 3;
    }
}
