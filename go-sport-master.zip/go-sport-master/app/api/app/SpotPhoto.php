<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpotPhoto extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'spot_id', 'title', 'caption', 'file',
    ];

    public function getFileAttribute($value)
    {
        return asset("storage/images/spot_photos/" . $value);
    }
}
