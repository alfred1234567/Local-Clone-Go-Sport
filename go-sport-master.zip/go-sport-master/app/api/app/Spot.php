<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Spot extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'category_id', 'name', 'address', 'price', 'reviews', 'facilities', 'description', 'ratings', 'photo',
    ];

    public function photos()
    {
        return $this->hasMany('App\SpotPhoto');
    }

    public function category()
    {
        return $this->belongsTo('App\Category');
    }

    public function courts()
    {
        return $this->hasMany('App\Court')->select(['id', 'name', 'points', 'price', 'photo']);
    }

    public function getPhotoAttribute($value)
    {
        return asset("storage/images/spots/" . $value);
    }
}
