<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Court extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'spot_id', 'name', 'points', 'price', 'photo',
    ];

    public function photos()
    {
        return $this->hasMany('App\CourtPhoto');
    }

    public function rooms()
    {
        return $this->hasMany('App\Room');
    }

    public function getPhotoAttribute($value)
    {
        return asset("storage/images/courts/" . $value);
    }
}
