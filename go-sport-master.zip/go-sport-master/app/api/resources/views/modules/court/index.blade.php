@extends('layouts.app')

@section('title', 'Court')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      @if (Session::has('success'))
        <div class="alert alert-success" role="alert">
          {{ Session::get('success') }}
        </div>
      @elseif ($errors->any())
        <div class="alert alert-danger" role="alert">
          <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @elseif (Session::has('error'))
        <div class="alert alert-danger" role="alert">
          {{ Session::get('error') }}
        </div>
      @endif
      <div class="table-responsive">
        <table id="datatable" class="table v-middle p-0 m-0 box" data-plugin="dataTable">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Points</th>
              <th>Price</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @foreach ($courts as $key => $court)
              <tr>
                <td>{{ $key + 1 }}</td>
                <th>{{ $court->name }}</th>
                <th>{{ $court->points }}</th>
                <th>Rp. {{ number_format($court->price, 2, ",", ".") }}</th>
                <td>
                  <a href="/court/{{ $court->id }}/rooms">Rooms</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection