@extends('layouts.app')

@section('title', 'Dashboard')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
	  <h4>Welcome to GO-SPORT Admin.</h4>
  </div>
@endsection