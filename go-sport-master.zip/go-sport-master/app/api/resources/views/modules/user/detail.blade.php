@extends('layouts.app')

@section('title', 'View User')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      <p class="mb-15">
        <a href="#" class="btn white d-inline" onclick="window.history.back();">Back</a>
        @if ($user->id === Auth::user()->id)
          <a href="/user/{{ $user->id }}/edit" class="btn primary d-inline">Edit</a>
        @endif
      </p>
      <div class="list box">
        <div class="list-item">
          <div class="list-body">
            <small class="d-block text-muted">Role</small>
            <h3 class="_500">{{ $user->role->name }}</h3>
          </div>
        </div>
        <div class="list-item">
          <div class="list-body">
            <small class="d-block text-muted">Name</small>
            <h3 class="_500">{{ $user->name }}</h3>
          </div>
        </div>
        <div class="list-item">
          <div class="list-body">
            <small class="d-block text-muted">Email</small>
            <h3 class="_500">{{ $user->email }}</h3>
          </div>
        </div>
        <div class="list-item">
          <div class="list-body">
            <small class="d-block text-muted">User ID</small>
            <h3 class="_500">{{ $user->user_id }}</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection