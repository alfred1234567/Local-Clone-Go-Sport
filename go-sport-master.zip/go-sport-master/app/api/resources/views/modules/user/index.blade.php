@extends('layouts.app')

@section('title', 'User')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      @if (Session::has('success'))
        <div class="alert alert-success" role="alert">
          {{ Session::get('success') }}
        </div>
      @elseif ($errors->any())
        <div class="alert alert-danger" role="alert">
          <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @elseif (Session::has('error'))
        <div class="alert alert-danger" role="alert">
          {{ Session::get('error') }}
        </div>
      @endif
      <p class="m-b">
        <a href="user/create" class="btn btn-fw white">Add</a>
      </p>
      <div class="table-responsive">
        <table id="datatable" class="table v-middle p-0 m-0 box" data-plugin="dataTable">
          <thead>
            <tr>
              <th>#</th>
              <th>Role</th>
              <th>Name</th>
              <th>Email</th>
              <th>User ID</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @foreach ($users as $key => $user)
              <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ $user->role->name }}</td>
                <td>{{ $user->name }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->user_id }}</td>
                <td>
                  <a href="/user/{{ $user->id }}/edit"><i class="fa fa-edit text-info mr-2"></i></a>
                  <a href="/user/{{ $user->id }}/delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')"><i class="fa fa-remove text-danger"></i></a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection