@extends('layouts.app')

@section('title', 'Edit User')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      <form action="{{ url('user/' . $user->id) }}" method="POST">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="form-group row">
          <label for="role" class="col-sm-2 col-form-label">Role</label>
          <div class="col-sm-10">
            <select name="role" class="form-control input-c">
              <option value="0">Choose role</option>
              <option value="1" @if($user->role_id === 1) selected @endif>Admin</option>
              <option value="3" @if($user->role_id === 3) selected @endif>Partner</option>
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label">Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="name" name="name" value="{{ $user->name }}" placeholder="Name">
          </div>
        </div>
        <div class="form-group row">
          <label for="email" class="col-sm-2 col-form-label">Email</label>
          <div class="col-sm-10">
            <input type="email" class="form-control" id="email" name="email" value="{{ $user->email }}" placeholder="Email">
          </div>
        </div>
        <div class="form-group row">
          <label for="password" class="col-sm-2 col-form-label">Password</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" id="password" name="password" placeholder="Password">
          </div>
        </div>
        <div class="form-group row">
          <label for="user_id" class="col-sm-2 col-form-label">User ID</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="user_id" name="user_id" value="{{ $user->user_id }}" placeholder="User ID">
          </div>
        </div>
        @if (Session::has('success'))
          <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
          </div>
        @elseif ($errors->any())
          <div class="alert alert-danger" role="alert">
            <ul>
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @elseif (Session::has('error'))
          <div class="alert alert-danger" role="alert">
            {{ Session::get('error') }}
          </div>
        @endif
        <button type="button" class="btn white d-inline" onclick="window.history.back();">Back</button>
        <button type="submit" class="btn primary">Save</button>
      </form>
    </div>
  </div>
@endsection