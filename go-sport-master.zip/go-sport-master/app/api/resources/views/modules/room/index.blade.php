@extends('layouts.app')

@section('title', 'Room')

@push('styles')
@endpush

@push('scripts')
  <script>
    $(document).ready(function() {

      function changeStatus() {
        var id = $(this).data('id');
        window.location = `/room/${id}/status?to=${this.value}`;
      }

      $('.cs').on('change', changeStatus);

    });
  </script>
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      @if (Session::has('success'))
        <div class="alert alert-success" role="alert">
          {{ Session::get('success') }}
        </div>
      @elseif ($errors->any())
        <div class="alert alert-danger" role="alert">
          <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @elseif (Session::has('error'))
        <div class="alert alert-danger" role="alert">
          {{ Session::get('error') }}
        </div>
      @endif
      <div class="table-responsive">
        <table id="datatable" class="table v-middle p-0 m-0 box" data-plugin="dataTable">
          <thead>
            <tr>
              <th>#</th>
              <th>Book Date</th>
              <th>Duration (hrs)</th>
              <th>Court Number</th>
              <th>Slot (people)</th>
              <th>Level</th>
              <th>Gender</th>
              <th>Age</th>
              <th>Players</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($rooms as $key => $room)
              @php
                $players = json_decode($room->players);
              @endphp
              <tr>
                <td>{{ $key + 1 }}</td>
                <td>{{ date('d/m/Y', strtotime($room->dt)) }}</td>
                <td>{{ $room->duration }}</td>
                <td>{{ $room->court_number }}</td>
                <td>{{ $room->slot }}</td>
                <td>{{ $room->level }}</td>
                <td>{{ $room->gender }}</td>
                <td>{{ $room->min_age }}-{{ $room->max_age }} y.o</td>
                <td>
                  @foreach ($players as $player)
                    <p>{{ $player->name }}({{ $player->age }}) - {{ $player->gender }}</p>
                  @endforeach
                </td>
                <td>
                  <select class="form-control input-c cs" data-id="{{ $room->id }}">
                    <option value="0" @if($room->paid === 0) selected @endif>Waiting</option>
                    <option value="1" @if($room->paid === 1) selected @endif>Paid</option>
                  </select>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection