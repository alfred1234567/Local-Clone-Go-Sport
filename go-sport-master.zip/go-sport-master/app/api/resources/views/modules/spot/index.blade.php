@extends('layouts.app')

@section('title', 'Spot')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      @if (Session::has('success'))
        <div class="alert alert-success" role="alert">
          {{ Session::get('success') }}
        </div>
      @elseif ($errors->any())
        <div class="alert alert-danger" role="alert">
          <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @elseif (Session::has('error'))
        <div class="alert alert-danger" role="alert">
          {{ Session::get('error') }}
        </div>
      @endif
      <div class="table-responsive">
        <table id="datatable" class="table v-middle p-0 m-0 box" data-plugin="dataTable">
          <thead>
            <tr>
              <th>#</th>
              <th>Category</th>
              <th>Name</th>
              <th>Address</th>
              <th>Price</th>
              <th>Reviews</th>
              <th>Facilities</th>
              <th>Description</th>
              <th>Ratings</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @foreach ($spots as $key => $spot)
              <tr>
                <td>{{ $key + 1 }}</td>
                <th>{{ $spot->category->name }}</th>
                <th>{{ $spot->name }}</th>
                <th>{{ $spot->address }}</th>
                <th>Rp. {{ number_format($spot->price, 2, ",", ".") }}</th>
                <th>{{ $spot->reviews }}</th>
                <th>{{ $spot->facilities }}</th>
                <th>{{ $spot->description }}</th>
                <th>{{ $spot->ratings }}</th>
                <td>
                  <a href="/spot/{{ $spot->id }}/courts">Courts</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection