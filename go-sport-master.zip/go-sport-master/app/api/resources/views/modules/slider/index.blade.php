@extends('layouts.app')

@section('title', 'Slider')

@push('styles')
@endpush

@push('scripts')
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      @if (Session::has('success'))
        <div class="alert alert-success" role="alert">
          {{ Session::get('success') }}
        </div>
      @elseif ($errors->any())
        <div class="alert alert-danger" role="alert">
          <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
          </ul>
        </div>
      @elseif (Session::has('error'))
        <div class="alert alert-danger" role="alert">
          {{ Session::get('error') }}
        </div>
      @endif
      <p class="m-b">
        <a href="slider/create" class="btn btn-fw white">Add</a>
      </p>
      <div class="table-responsive">
        <table id="datatable" class="table v-middle p-0 m-0 box" data-plugin="dataTable">
          <thead>
            <tr>
              <th>#</th>
              <th>Image</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            @foreach ($sliders as $key => $slider)
              <tr>
                <td>{{ $key + 1 }}</td>
                <td><img src="{{ $slider->file }}" width="250" alt=""></td>
                <td>
                  <a href="/slider/{{ $slider->id }}/edit"><i class="fa fa-edit text-info mr-2"></i></a>
                  <a href="/slider/{{ $slider->id }}/delete" onclick="return confirm('Are you sure want to delete this item?')"><i class="fa fa-remove text-danger"></i></a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
@endsection