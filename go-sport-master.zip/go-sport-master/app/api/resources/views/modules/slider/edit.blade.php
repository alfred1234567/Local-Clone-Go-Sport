@extends('layouts.app')

@section('title', 'Edit Slider')

@push('styles')
@endpush

@push('scripts')
  <script>
    $(document).ready(function() {
      $("#img").change(function(){
        $("#img_filename").text(this.files[0].name);
      });
    });
  </script>
@endpush

@section('content')
  <div class="padding">
    <div class="padding box">
      <form action="{{ url('slider/' . $slider->id) }}" method="POST" enctype="multipart/form-data">
        {{ csrf_field() }}
        {{ method_field('PUT') }}
        <div class="form-group row">
          <label for="img" class="col-sm-2 col-form-label">Image File</label>
          <div class="col-sm-10">
            @if ($slider->file != null)
              <div class="mb-10">
                <img src="{{ $slider->file }}" width="250" height="150" alt="">
              </div>
            @endif
            <div class="form-file">
              <input type="file" id="img" name="img">
              <button class="btn white">Choose image ...</button>
              <small id="img_filename"></small>
            </div>
          </div>
        </div>
        @if (Session::has('success'))
          <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
          </div>
        @elseif ($errors->any())
          <div class="alert alert-danger" role="alert">
            <ul>
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @elseif (Session::has('error'))
          <div class="alert alert-danger" role="alert">
            {{ Session::get('error') }}
          </div>
        @endif
        <button type="button" class="btn white d-inline" onclick="window.history.back();">Back</button>
        <button type="submit" class="btn primary">Save</button>
      </form>
    </div>
  </div>
@endsection