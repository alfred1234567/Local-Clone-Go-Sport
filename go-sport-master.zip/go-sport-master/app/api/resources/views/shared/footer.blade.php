<!-- Footer -->
<div class="content-footer white " id="content-footer">
  <div class="d-flex p-3">
    <span class="text-sm text-muted flex">&copy; Copyright. Tim Googol</span>
    <div class="text-sm text-muted">Version 1.0.0</div>
  </div>
</div>