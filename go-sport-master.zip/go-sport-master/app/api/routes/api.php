<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login', 'API\UserController@login');
Route::post('register', 'API\UserController@register');
Route::get('profile/{id}', 'API\UserController@getProfile');
Route::post('profile/{id}/edit', 'API\UserController@editProfile');
Route::get('sliders', 'API\SliderController@all');
Route::get('spots/{categoryId}', 'API\SpotController@getSpotList');
Route::get('spot/{id}/details', 'API\SpotController@getDetails');
Route::get('spot/{id}/courts', 'API\SpotController@getCourts');
Route::get('court/{id}/details', 'API\CourtController@getDetails');
Route::post('court/{id}/room', 'API\CourtController@createRoom');
Route::get('room/{id}/details', 'API\RoomController@getDetails');
Route::post('room/{id}/join', 'API\RoomController@join');
