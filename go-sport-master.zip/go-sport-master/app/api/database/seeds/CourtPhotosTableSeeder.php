<?php

use Illuminate\Database\Seeder;
use App\CourtPhoto;

class CourtPhotosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        CourtPhoto::insert([
            [
                'court_id' => 1,
                'title' => 'Kolam Renang',
                'caption' => 'Kolam Renang',
                'file' => '1.jpg',
            ],
            [
                'court_id' => 2,
                'title' => 'Gym',
                'caption' => 'Gym',
                'file' => '2.jpg',
            ],
            [
                'court_id' => 3,
                'title' => 'Basket',
                'caption' => 'Lapangan Basket',
                'file' => '3.jpg',
            ],
        ]);
    }
}
