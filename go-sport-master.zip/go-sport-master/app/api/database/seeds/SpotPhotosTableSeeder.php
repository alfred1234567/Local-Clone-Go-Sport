<?php

use Illuminate\Database\Seeder;
use App\SpotPhoto;

class SpotPhotosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SpotPhoto::insert([
            [
                'spot_id' => 1,
                'title' => 'Tangkas Sport Centre',
                'caption' => 'Tangkas',
                'file' => '1.jpg',
            ],
            [
                'spot_id' => 2,
                'title' => 'Smash',
                'caption' => 'Smash',
                'file' => '2.jpg',
            ],
            [
                'spot_id' => 3,
                'title' => 'CWIBC',
                'caption' => 'CWIBC',
                'file' => '3.jpg',
            ],
            [
                'spot_id' => 4,
                'title' => 'Osdara',
                'caption' => 'Tangkas',
                'file' => '4.jpg',
            ],
            [
                'spot_id' => 5,
                'title' => 'Garuda',
                'caption' => 'Garuda',
                'file' => '5.jpg',
            ]
        ]);
    }
}
