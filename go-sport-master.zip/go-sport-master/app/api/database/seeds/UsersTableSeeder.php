<?php

use Illuminate\Database\Seeder;
use App\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::insert([
            ['role_id' => 1, 'user_id' => 'admin', 'name' => 'Administrator', 'email' => 'admin@gosport.id', 'phone' => '081329892323', 'gender' => 'female', 'password' => bcrypt('12345'), 'age' => 30], // Admin
            ['role_id' => 2, 'user_id' => 'user', 'name' => 'User', 'email' => 'user@gosport.id', 'phone' => '081812782718', 'gender' => 'male', 'password' => bcrypt('12345'), 'age' => 28], // User,
            ['role_id' => 3, 'user_id' => 'partner', 'name' => 'Partner', 'email' => 'partner@gosport.id', 'phone' => '0987812892', 'gender' => 'female', 'password' => bcrypt('12345'), 'age' => 29], // Partner,
        ]);
    }
}
