<?php

use Illuminate\Database\Seeder;
use App\Court;

class CourtsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Court::insert([
            [
                'spot_id' => 3,
                'name' => 'Lapangan Kayu 1',
                'points' => 10,
                'price' => 65000,
                'photo' => '1.png',
            ],
            [
                'spot_id' => 3,
                'name' => 'Lapangan Kayu 2',
                'points' => 8,
                'price' => 60000,
                'photo' => '2.jpg',
            ],
            [
                'spot_id' => 3,
                'name' => 'Lapangan Karpet 1',
                'points' => 20,
                'price' => 77000,
                'photo' => '3.jpg',
            ],
            [
                'spot_id' => 4,
                'name' => 'Lapangan Kayu 2',
                'points' => 8,
                'price' => 62000,
                'photo' => '2.jpg',
            ],
            [
                'spot_id' => 4,
                'name' => 'Lapangan Karpet 1',
                'points' => 20,
                'price' => 71000,
                'photo' => '3.jpg',
            ],
        ]);
    }
}
