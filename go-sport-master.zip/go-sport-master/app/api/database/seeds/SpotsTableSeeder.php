<?php

use Illuminate\Database\Seeder;
use App\Spot;

class SpotsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Spot::insert([
            [
                'category_id' => 1,
                'partner_id' => 3,
                'name' => 'Tangkas Sport Centre',
                'address' => 'Tahap III, Jl. Tanjung Duren Komplek Greenville Blok Q, RT.11/RW.9, Duri Kepa, Kb. Jeruk, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11510',
                'price' => 100000,
                'ratings' => 4.2,
                'reviews' => 'Recommended!',
                'facilities' => 'AC, Gym, Cafetaria',
                'description' => 'Salah satu tempat olahraga yang harus kamu datangi adalah Tangkas Sports Centre. Ini adalah fasilitas olahraga terbesar dan terlengkap di Jakarta Barat. Fasilitas ini telah berdiri sejak 30 tahunan yang lalu. Hingga saat ini, Tangkas Sports Centre masih menjadi pilihan favorit masyarakat untuk berolahraga sekaligus berekreasi.',
                'photo' => 'tangkas.jpg',
            ],
            [
                'category_id' => 3,
                'partner_id' => 3,
                'name' => 'Smash Badminton Hall',
                'address' => 'RT.13/RW.7, Duri Kosambi, Cengkareng, West Jakarta City, Jakarta 11750',
                'price' => 75000,
                'ratings' => 4.5,
                'reviews' => 'Recommended!',
                'facilities' => 'AC, Gym, Cafetaria',
                'description' => 'Salah satu tempat olahraga yang harus kamu datangi adalah Tangkas Sports Centre. Ini adalah fasilitas olahraga terbesar dan terlengkap di Jakarta Barat. Fasilitas ini telah berdiri sejak 30 tahunan yang lalu. Hingga saat ini, Tangkas Sports Centre masih menjadi pilihan favorit masyarakat untuk berolahraga sekaligus berekreasi.',
                'photo' => 'smash.jpg',
            ],
            [
                'category_id' => 3,
                'partner_id' => 3,
                'name' => 'Candra Wijaya Int\'l Badminton Club',
                'address' => 'Jalan Jelupang Raya No.15, Serpong Utara, Jelupang, Serpong Utara, Kota Tangerang Selatan, Banten 15323',
                'price' => 90000,
                'ratings' => 4.7,
                'reviews' => 'Recommended!',
                'facilities' => 'AC, Gym, Cafetaria',
                'description' => 'Salah satu tempat olahraga yang harus kamu datangi adalah Tangkas Sports Centre. Ini adalah fasilitas olahraga terbesar dan terlengkap di Jakarta Barat. Fasilitas ini telah berdiri sejak 30 tahunan yang lalu. Hingga saat ini, Tangkas Sports Centre masih menjadi pilihan favorit masyarakat untuk berolahraga sekaligus berekreasi.',
                'photo' => 'cwibc.jpg',
            ],
            [
                'category_id' => 3,
                'partner_id' => 3,
                'name' => 'Osdara Badminton Hall',
                'address' => 'Kenanga, Cipondoh, Tangerang City, Banten 15148',
                'price' => 65000,
                'ratings' => 4.3,
                'reviews' => 'Recommended!',
                'facilities' => 'AC, Gym, Cafetaria',
                'description' => 'Salah satu tempat olahraga yang harus kamu datangi adalah Tangkas Sports Centre. Ini adalah fasilitas olahraga terbesar dan terlengkap di Jakarta Barat. Fasilitas ini telah berdiri sejak 30 tahunan yang lalu. Hingga saat ini, Tangkas Sports Centre masih menjadi pilihan favorit masyarakat untuk berolahraga sekaligus berekreasi.',
                'photo' => 'osdara.png',
            ],
            [
                'category_id' => 3,
                'partner_id' => 3,
                'name' => 'Garuda badminton',
                'address' => 'Jl. Perdana Kusuma Blok Qq No.248 B, RT.1/RW.4, Wijaya Kusuma, Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11460',
                'price' => 87000,
                'ratings' => 4.4,
                'reviews' => 'Recommended!',
                'facilities' => 'AC, Gym, Cafetaria',
                'description' => 'Salah satu tempat olahraga yang harus kamu datangi adalah Tangkas Sports Centre. Ini adalah fasilitas olahraga terbesar dan terlengkap di Jakarta Barat. Fasilitas ini telah berdiri sejak 30 tahunan yang lalu. Hingga saat ini, Tangkas Sports Centre masih menjadi pilihan favorit masyarakat untuk berolahraga sekaligus berekreasi.',
                'photo' => 'garuda.jpg',
            ],
        ]);
    }
}
