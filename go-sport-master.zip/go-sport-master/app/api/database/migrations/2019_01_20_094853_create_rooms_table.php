<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRoomsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rooms', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('court_id');
            $table->dateTime('dt');
            $table->integer('duration');
            $table->integer('court_number');
            $table->integer('slot');
            $table->enum('level', array('Beginner', 'Normal', 'Professional'))->default('Beginner');
            $table->enum('gender', array('Male', 'Female', 'Both'))->default('Both');
            $table->integer('min_age');
            $table->integer('max_age');
            $table->longText('players')->nullable(); // in JSON
            $table->boolean('paid')->default(false);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('court_id')->references('id')->on('courts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rooms');
    }
}
