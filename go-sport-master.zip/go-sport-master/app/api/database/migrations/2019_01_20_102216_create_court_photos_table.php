<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCourtPhotosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('court_photos', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('court_id');
            $table->string('title');
            $table->string('caption');
            $table->string('file');
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('court_id')->references('id')->on('courts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('court_photos');
    }
}
