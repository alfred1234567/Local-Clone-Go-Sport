import React from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  Image
} from 'react-native';

export default ({item, navigation}) => (
  <TouchableOpacity
    activeOpacity={.7}
    onPress={() => null}
  >
    <Image
      resizeMode="stretch"
      source={item.url}
      style={styles.photo}
    />
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  photo: {
    width: 200,
    height: 100
  }
});