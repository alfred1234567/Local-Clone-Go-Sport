import React from 'react';
import {
  StyleSheet,
  Dimensions,
  Text,
  TouchableOpacity,
  Image
} from 'react-native';
import {
  NUM_CT_GRID_COLUMNS,
  CT_ITEM_HEIGHT,
  CT_ITEM_OFFSET,
  CT_ITEM_MARGIN
} from "./../constants";
import c from './../colors';

const {height, width} = Dimensions.get("window");
const SCREEN_WIDTH = width < height ? width : height;

export default ({item, navigation}) => (
  <TouchableOpacity
    activeOpacity={.7}
    style={styles.container}
    onPress={() => navigation.navigate('CategoryList', { category: item })}
  >
    <Image
      resizeMode="contain"
      source={item.icon}
      style={styles.itemImage}
    />
    <Text style={styles.itemName}>{item.name}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    margin: CT_ITEM_OFFSET,
    backgroundColor: c.white,
    overflow: 'hidden',
    borderRadius: 10,
    width: (SCREEN_WIDTH - CT_ITEM_MARGIN) / NUM_CT_GRID_COLUMNS - CT_ITEM_MARGIN,
    height: CT_ITEM_HEIGHT,
    flexDirection: 'column',
    elevation: 2
  },
  itemImage: {
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignSelf: 'center'
  },
  itemName: {
    flex: 1,
    textAlign: 'center',
    margin: CT_ITEM_OFFSET,
    fontFamily: 'VAGRounded_BT',
    fontSize: 14,
    color: c.black
  }
});