import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity
} from 'react-native';
import moment from 'moment';
import c from './../colors';
import cs from './../commonStyles';
import {formatPrice} from './../helpers';

export default ({item, price, navigation, overrideStyle}) => (
  <TouchableOpacity
    activeOpacity={.7}
    style={[styles.itemContainer, {borderColor: item.paid ? c.material_green : c.primary_darker}, overrideStyle && {...overrideStyle}]}
    onPress={() => navigation.navigate('JoinRoom', {roomId: item.id})}
  >
    <View style={[cs.row, styles.detailRow]}>
      <View style={cs.fl2}>
        <Text>Date/Time</Text>
      </View>
      <View style={cs.fl05}>
        <Text>:</Text>
      </View>
      <View style={cs.fl5}>
        <Text style={styles.detailValue}>{moment(item.dt).format("lll")}</Text>
      </View>
    </View>
    <View style={[cs.row, styles.detailRow]}>
      <View style={cs.fl2}>
        <Text>Duration</Text>
      </View>
      <View style={cs.fl05}>
        <Text>:</Text>
      </View>
      <View style={cs.fl5}>
        <Text style={styles.detailValue}>{item.duration} hrs</Text>
      </View>
    </View>
    <View style={[cs.row, styles.detailRow]}>
      <View style={cs.fl2}>
        <Text>Slot</Text>
      </View>
      <View style={cs.fl05}>
        <Text>:</Text>
      </View>
      <View style={cs.fl5}>
        <Text style={styles.detailValue}>{item.slot} players</Text>
      </View>
    </View>
    <View style={[cs.row, styles.detailRow]}>
      <View style={cs.fl2}>
        <Text>Fare</Text>
      </View>
      <View style={cs.fl05}>
        <Text>:</Text>
      </View>
      <View style={cs.fl5}>
        <Text style={styles.detailValue}>Rp {formatPrice(price)}/hr</Text>
      </View>
    </View>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  detailRow: {
    paddingBottom: 4
  },
  itemContainer: {
    padding: 10,
    backgroundColor: c.white,
    borderRadius: 10,
    borderWidth: 1
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'VAGRoundedBT-Regular'
  }
});