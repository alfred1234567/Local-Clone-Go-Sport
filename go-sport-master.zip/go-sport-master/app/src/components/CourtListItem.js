import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  TouchableOpacity
} from 'react-native';
import c from './../colors';
import cs from './../commonStyles';
import {formatPrice} from './../helpers';

export default ({item, navigation, overrideStyle}) => (
  <TouchableOpacity
    activeOpacity={.7}
    style={[styles.itemContainer, overrideStyle && {...overrideStyle}]}
    onPress={() => navigation.navigate('CourtDetails', {item})}
  >
    <View style={cs.row}>
      <Image
        style={styles.thumbnail}
        source={{uri: item.photo}}
        resizeMode="contain"
      />
      <View style={styles.rightContainer}>
        <View style={styles.detailContainer}>
          <Text style={[styles.detailText, styles.name]}>{item.name}</Text>
        </View>
        <View style={styles.detailContainer}>
          <Text style={styles.detailText}>{item.points} Points</Text>
        </View>
        <View style={styles.detailContainer}>
          <Text style={[styles.detailText, styles.price]}>Rp {formatPrice(item.price)}/hr</Text>
        </View>
      </View>
    </View>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  itemContainer: {
    padding: 10,
    backgroundColor: c.white,
    borderRadius: 10,
    elevation: 2
  },
  thumbnail: {
    width: 150,
    height: 150
  },
  rightContainer: {
    flex: 1,
    flexDirection: 'column',
    padding: 8
  },
  detailContainer: {
    padding: 4
  },
  detailText: {
    fontFamily: 'VAGRoundedStd-Thin',
    fontSize: 12
  },
  name: {
    fontFamily: 'VAGRounded_BT',
    fontSize: 16
  },
  price: {
    fontFamily: 'VAGRounded_BT'
  },
  star: {
    width: 100,
    height: 20,
    marginBottom: 5
  }
});