import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Text,
  ToastAndroid,
  TouchableOpacity
} from 'react-native';
import c from './../colors';
import cs from './../commonStyles';
import Icon from 'react-native-vector-icons/Entypo';

class Toolbar extends Component {
  _renderLeft() {
    const {
      title,
      canGoBack,
      _onBackPress,
      _openDrawer
    } = this.props;

    return canGoBack ? (
      <TouchableOpacity
        activeOpacity={.7}
        style={styles.drToggle}
        onPress={() => _onBackPress()}
      >
        <Icon
          name="chevron-left"
          size={36}
          color={c.primary}
          style={cs.transparent}
        />
        <Text style={styles.title}>{title}</Text>
      </TouchableOpacity>
    ) : (
      <TouchableOpacity
        activeOpacity={.7}
        style={styles.drToggle}
        onPress={() => _openDrawer()}
      >
        <Icon
          name="menu"
          size={36}
          color={c.primary}
          style={cs.transparent}
        />
        <Text style={styles.title}>{title}</Text>
      </TouchableOpacity>
    );
  }
  _renderRight() {
    return this.props._hasNotification ? (
        <TouchableOpacity
          activeOpacity={.7}
          style={styles.right}
          onPress={() => ToastAndroid.show("Nice to have, bro!", ToastAndroid.SHORT)}
        >
          <Icon
            name="bell"
            size={24}
            color={c.primary}
            style={cs.transparent}
          />
        </TouchableOpacity>
      ) : null;
  }
  render() {
    return (
      <View style={styles.container}>
        {this._renderLeft()}
        {this._renderRight()}
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: c.white,
    elevation: 2
  },
  title: {
    paddingHorizontal: 20,
    fontFamily: 'VAGRounded_BT',
    fontSize: 18,
    color: c.primary,
    backgroundColor: 'transparent'
  },
  drToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10
  },
  right: {
    paddingRight: 15
  }
});

export default Toolbar;