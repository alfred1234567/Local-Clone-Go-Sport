import React, {Component} from 'react';
import {
  StyleSheet,
  ScrollView,
  View,
  Text,
  Image,
  TouchableOpacity,
  StatusBar
} from 'react-native';
import Slideshow from 'react-native-slideshow';
import Star from 'react-native-star-view';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import CarouselItem from './../components/CarouselItem';
import {spotImageItems} from './../constants';
import API from "./../api";
import spinner from "./../../assets/loading.gif";

class SpotDetailsScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      spot: this.props.navigation.getParam('item', null),
      details: null,
      isLoading: false,
      position: 0,
      interval: null
    };
  }
  componentWillMount() {
    this._loadDetails();
    this.setState({
      interval: setInterval(() => {
        this.setState({
          position: this.state.position === spotImageItems.length ? 0 : this.state.position + 1
        });
      }, 5000)
    });
  }
  componentWillUnmount() {
    this._timeout && clearTimeout(this._timeout);
    clearInterval(this.state.interval);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={this.state.spot.name ? this.state.spot.name : 'Loading...'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderBody() {
    const { isLoading, details } = this.state;

    if (isLoading) {
      return (
        <View style={styles.detailsLoadingContainer}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    let sliders = [];
    details.photos.map((photo) => {
      sliders.push({
        title: photo.title,
        caption: photo.caption,
        url: photo.file
      });
    });

    return (
      <View style={cs.fl1}>
        <Slideshow
          dataSource={sliders}
          position={this.state.position}
          onPositionChanged={position => this.setState({ position })}
          indicatorSelectedColor={c.primary}
        />
        <View style={[cs.fl1, styles.detailsContainer]}>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Nama Sport Center</Text>
            <Text style={styles.detailValue}>{details.name}</Text>
          </View>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Lokasi</Text>
            <Text style={styles.detailValue}>{details.address}</Text>
          </View>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Ratings</Text>
            <Star score={details.ratings} style={styles.star} />
          </View>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Ulasan</Text>
            <Text style={styles.detailValue}>{details.reviews}</Text>
          </View>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Fasilitas</Text>
            <Text style={styles.detailValue}>{details.facilities}</Text>
          </View>
          <View style={styles.detailSection}>
            <Text style={styles.detailLabel}>Deskripsi Sport Center</Text>
            <Text style={styles.detailValue}>{details.description}</Text>
          </View>
        </View>
      </View>
    );
  }
  _renderCarouselItem = ({item}) => (
    <CarouselItem item={item} navigation={this.props.navigation} />
  );
  _renderFloatingButton() {
    return (
      <View style={styles.floatingButtonContainer}>
        <TouchableOpacity
          activeOpacity={.7}
          style={styles.floatingButton}
          onPress={() => this.props.navigation.navigate('CourtList', {spot: this.state.spot})}
        >
          <Text style={styles.floatingButtonText}>SELECT COURT</Text>
        </TouchableOpacity>
      </View>
    );
  }
  _loadDetails() {
    this.setState({
      isLoading: true
    });

    const { spot } = this.state;

    if (spot) {

      API.get(`spot/${spot.id}/details`)
        .then(res => {
          if (res.data.success) {
            const { spot } = res.data.success;
            
            this.setState({
              isLoading: false,
              details: spot
            });
          }
        })
        .catch(error => {
          this.setState(
            {
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={[cs.fl1, styles.container]}
          showsVerticalScrollIndicator={false}
        >
          {this._renderBody()}
        </ScrollView>
        {this._renderFloatingButton()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: c.white
  },
  detailsLoadingContainer: {
    paddingTop: 15,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  loading: {
    width: 32,
    height: 32
  },
  detailsContainer: {
    padding: 15,
    paddingBottom: 100
  },
  detailSection: {
    marginBottom: 10
  },
  detailLabel: {
    fontSize: 12,
    fontWeight: '400'
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  star: {
    width: 100,
    height: 20,
    marginBottom: 5
  },
  floatingButtonContainer: {
    position: 'absolute',
    bottom: 10,
    right: 10
  },
  floatingButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: c.primary_darker,
    padding: 10,
    width: 85,
    height: 85,
    borderRadius: 85,
    elevation: 2
  },
  floatingButtonText: {
    flex: 1,
    flexWrap: 'wrap',
    textAlign: 'center',
    fontFamily: 'VAGRounded_BT',
    fontSize: 14,
    color: c.white
  }
});

export default SpotDetailsScreen;