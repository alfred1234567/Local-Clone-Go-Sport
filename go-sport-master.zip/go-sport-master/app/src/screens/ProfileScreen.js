import React, {Component} from 'react';
import {
  StyleSheet,
  ScrollView,
  AsyncStorage,
  Alert,
  View,
  Text,
  TouchableOpacity,
  ToastAndroid,
  Image,
  StatusBar
} from 'react-native';
import {
  NavigationActions,
  StackActions
} from 'react-navigation';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import API from "./../api";
import UserStore from "./../mobx/userStore";
import spinner from "./../../assets/loading.gif";
const PP = require('./../../assets/pp.jpg');

class ProfileScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      profile: {},
      isLoading: false,
    };
  }
  componentDidMount() {
    this.didFocusListener = this.props.navigation.addListener(
      'didFocus',
      () => this._loadProfile()
    );
  }
  componentWillMount() {
    this._loadProfile();
  }
  componentWillUnmount() {
    this.didFocusListener.remove();
    this._timeout && clearTimeout(this._timeout);
  }
  _loadProfile() {
    this.setState({
      isLoading: true
    });

    const user = JSON.parse(UserStore.user);

    if (user) {

      API.get(`profile/${user.id}`)
        .then(res => {
          if (res.data.success) {
            const profile = res.data.success;
            
            this.setState({
              isLoading: false,
              profile
            });
          }
        })
        .catch(error => {
          this.setState(
            {
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'PROFILE'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderProfile() {
    const { isLoading, profile } = this.state;

    if (isLoading) {
      return (
        <View style={styles.profileLoadingContainer}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    return (
      <ScrollView
        style={cs.fl1}
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.photoContainer}>
          <Image
            resizeMode={'contain'}
            source={PP}
            style={styles.pp}
          />
          <Text style={styles.name}>{profile.name}</Text>
          <TouchableOpacity
            style={[cs.formButton, {
              marginTop: 10,
              paddingHorizontal: 15,
              backgroundColor: c.soft_gray
            }]}
            activeOpacity={.7}
            onPress={() => this.props.navigation.navigate('EditProfile', {profile})}
          >
            <Text style={[cs.formButtonLabel, {
              color: c.primary,
              fontSize: 16
            }]}>EDIT</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.bioContainer}>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>Email</Text>
            </View>
            <View style={styles.sectionBody}>
              <Text style={styles.sectionBodyText}>{profile.email}</Text>
            </View>
          </View>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>Phone</Text>
            </View>
            <View style={styles.sectionBody}>
              <Text style={styles.sectionBodyText}>{profile.phone}</Text>
            </View>
          </View>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>Gender</Text>
            </View>
            <View style={styles.sectionBody}>
              <Text style={styles.sectionBodyText}>{profile.gender}</Text>
            </View>
          </View>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>Age</Text>
            </View>
            <View style={styles.sectionBody}>
              <Text style={styles.sectionBodyText}>{profile.age} y.o</Text>
            </View>
          </View>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionHeaderText}>Point</Text>
            </View>
            <View style={styles.sectionBody}>
              <Text style={styles.sectionBodyText}>0</Text>
            </View>
          </View>
        </View>
        <TouchableOpacity
          style={[cs.formButton, {
            marginTop: 5,
            marginBottom: 5,
            backgroundColor: c.soft_gray
          }]}
          activeOpacity={.7}
          onPress={() => this._logout()}
        >
          <Text style={[cs.formButtonLabel, {
            color: c.primary,
            fontSize: 16
          }]}>LOG OUT</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }
  _logout() {
    Alert.alert(
      "Log Out Confirmation",
      "Are you sure that you want to log out?",
      [
        {text: "Cancel", style: "cancel"},
        {text: "OK", onPress: async () => {
          try {
            await AsyncStorage.removeItem('user');
            UserStore.updateUser(null);
            this._navigateTo('Home');
            ToastAndroid.show("You've been logged out", ToastAndroid.SHORT);
          } catch (error) {
            ToastAndroid.show("There is an error while logging out, please try again later.", ToastAndroid.SHORT);
          }
        }}
      ]
    );
  }
  _navigateTo(routeName, params) {
    const resetAction = StackActions.reset({
      index: 0,
      actions: [NavigationActions.navigate({ routeName, params })]
    });
    this.props.navigation.dispatch(resetAction);
  }
  render() {
    return (
      <View style={[cs.fl1, {backgroundColor: c.white}]}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        {this._renderProfile()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 15
  },
  profileLoadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  loading: {
    width: 32,
    height: 32
  },
  photoContainer: {
    padding: 5,
    alignItems: 'center'
  },
  pp: {
    width: 150,
    height: 150,
    borderRadius: 150
  },
  bioContainer: {
    flexDirection: 'column',
    paddingTop: 10
  },
  name: {
    marginTop: 8,
    fontSize: 16,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  sectionHeader: {
    padding: 10,
    backgroundColor: c.primary,
    borderRadius: 5
  },
  sectionHeaderText: {
    fontFamily: 'VAGRounded_BT',
    fontSize: 16,
    color: c.white
  },
  section: {
    marginBottom: 15
  },
  sectionBody: {
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center'
  },
  sectionBodyText: {
    fontSize: 18,
    fontFamily: 'VAGRoundedBT-Regular',
    color: c.black
  }
});

export default ProfileScreen;