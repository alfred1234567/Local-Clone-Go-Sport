import React, {Component} from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ToastAndroid,
  StatusBar
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';

class ForgotPasswordScreen extends Component {
  _renderToolbar() {
    return (
      <Toolbar
        title={'FORGOT PASSWORD'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderForm() {
    return (
      <View style={cs.boxForm}>
        <Text style={cs.formLabel}>Please enter your email below.</Text>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-mail"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            placeholder={'Email Address'}
            underlineColorAndroid={'transparent'}
          />
        </View>
        <TouchableOpacity
          style={[cs.formButton, {backgroundColor: c.primary}]}
          activeOpacity={.7}
          onPress={() => {
            ToastAndroid.show("Please check your email to reset your password.", ToastAndroid.SHORT);
            this.props.navigation.goBack();
          }}
        >
          <Text style={cs.formButtonLabel}>SEND MY PASSWORD</Text>
        </TouchableOpacity>
      </View>
    );
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={[cs.fl1, {backgroundColor: c.material_gray}]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={'handled'}
        >
          <KeyboardAvoidingView style={[cs.fl1, styles.container]} enabled>
            {this._renderForm()}
          </KeyboardAvoidingView>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 25,
    paddingVertical: 15
  }
});

export default ForgotPasswordScreen;