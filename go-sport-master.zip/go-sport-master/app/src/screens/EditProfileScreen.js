import React, {Component} from 'react';
import {
  StyleSheet,
  ScrollView,
  View,
  Text,
  TextInput,
  Picker,
  TouchableOpacity,
  ToastAndroid,
  Image,
  StatusBar
} from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';
import NumericInput from 'react-native-numeric-input';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import API from './../api';
import { isEmpty } from "./../helpers";
import spinner from "./../../assets/loading.gif";
const PP = require('./../../assets/pp.jpg');

const genderOptions = [
  {
    id: 1,
    label: "Male",
    value: "male"
  },
  {
    id: 2,
    label: "Female",
    value: "female"
  }
];

class EditProfileScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      profile: this.props.navigation.getParam('profile', null),
      password: "",
      buttonDisabled: false,
      isLoading: false
    };
  }
  componentWillUnmount() {
    clearTimeout(this._timeout);
  }
  _validateEmail(email) {
    return /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'EDIT PROFILE'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
      />
    );
  }
  _choosePhoto() {
    ImagePicker.openPicker({
      width: 500,
      height: 500,
      cropping: true
    })
      .then(image => {
        this.setState({
          photo: {
            uri: image.path,
            width: image.width,
            height: image.height,
            type: 'image/jpeg',
            name: 'photo.jpg',
            mime: image.mime
          }
        });
      })
      .catch(error => {
        Alert.alert(error.message ? error.message : error);
      });
  }
  _submit() {
    if (this.state.isLoading) return;

    const {
      password,
      profile
    } = this.state;

    // Validate user's input
    if (isEmpty(profile.user_id)) {
      return ToastAndroid.show("User ID can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(profile.email)) {
      return ToastAndroid.show("Email can't be empty.", ToastAndroid.SHORT);
    } else if (!this._validateEmail(profile.email)) {
      return ToastAndroid.show("Email format is not valid.", ToastAndroid.SHORT);
    } else if (isEmpty(profile.name)) {
      return ToastAndroid.show("Name can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(profile.gender)) {
      return ToastAndroid.show("Please choose your gender.", ToastAndroid.SHORT);
    } else if (isEmpty(profile.phone)) {
      return ToastAndroid.show("Phone can't be empty.", ToastAndroid.SHORT);
    }

    this.setState({
      buttonDisabled: true,
      isLoading: true
    });

    this._timeout = setTimeout(() => {
      API.post(`profile/${profile.id}/edit`, JSON.stringify({
        user_id: profile.user_id,
        name: profile.name,
        email: profile.email,
        password: password || null,
        gender: profile.gender,
        phone: profile.phone,
        age: profile.age
      }))
        .then(res => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (res.data.success) {
                ToastAndroid.show("Edit profile success", ToastAndroid.SHORT);
                this.props.navigation.goBack();
              } else {
                ToastAndroid.show(res.data.error.message, ToastAndroid.SHORT);
              }
            }
          );
        })
        .catch(error => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              alert(error);
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }, 2000);
  }
  render() {
    const { profile } = this.state;

    return (
      <View style={[cs.fl1, {backgroundColor: c.white}]}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={cs.fl1}
          contentContainerStyle={styles.container}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.photoContainer}>
            <Image
              resizeMode={'contain'}
              source={PP}
              style={styles.pp}
            />
            {/* <TouchableOpacity
              style={[cs.formButton, {
                marginTop: 10,
                paddingHorizontal: 15,
                backgroundColor: c.soft_gray
              }]}
              activeOpacity={.7}
              onPress={() => this._choosePhoto()}
            >
              <Text style={[cs.formButtonLabel, {
                color: c.primary,
                fontSize: 16
              }]}>CHOOSE PHOTO</Text>
            </TouchableOpacity> */}
          </View>
          <View style={styles.bioContainer}>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Email</Text>
              </View>
              <View style={styles.sectionBody}>
                <TextInput
                  style={cs.fieldInput}
                  placeholder={'Email Address'}
                  underlineColorAndroid={c.soft_gray}
                  value={profile.email}
                  onChangeText={email => this.setState(prevSTate => ({
                    ...prevSTate,
                    profile: {
                      ...prevSTate.profile,
                      email
                    }
                  }))}
                />
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Password</Text>
              </View>
              <View style={styles.sectionBody}>
                <TextInput
                  style={cs.fieldInput}
                  placeholder={'Password'}
                  secureTextEntry={true}
                  underlineColorAndroid={c.soft_gray}
                  value={this.state.password}
                  onChangeText={password => this.setState({password})}
                />
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>User ID</Text>
              </View>
              <View style={styles.sectionBody}>
                <TextInput
                  style={cs.fieldInput}
                  placeholder={'User ID'}
                  underlineColorAndroid={c.soft_gray}
                  value={profile.user_id}
                  onChangeText={user_id => this.setState(prevSTate => ({
                    ...prevSTate,
                    profile: {
                      ...prevSTate.profile,
                      user_id
                    }
                  }))}
                />
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Name</Text>
              </View>
              <View style={styles.sectionBody}>
                <TextInput
                  style={cs.fieldInput}
                  placeholder={'Name'}
                  underlineColorAndroid={c.soft_gray}
                  value={profile.name}
                  onChangeText={name => this.setState(prevSTate => ({
                    ...prevSTate,
                    profile: {
                      ...prevSTate.profile,
                      name
                    }
                  }))}
                />
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Phone</Text>
              </View>
              <View style={styles.sectionBody}>
                <TextInput
                  style={cs.fieldInput}
                  placeholder={'Phone Number'}
                  underlineColorAndroid={c.soft_gray}
                  value={profile.phone}
                  keyboardType={'phone-pad'}
                  onChangeText={phone => this.setState(prevSTate => ({
                    ...prevSTate,
                    profile: {
                      ...prevSTate.profile,
                      phone
                    }
                  }))}
                />
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Gender</Text>
              </View>
              <View style={styles.sectionBody}>
                <Picker
                  selectedValue={profile.gender}
                  style={cs.fl1}
                  onValueChange={(gender, genderIndex) => this.setState(prevSTate => ({
                    ...prevSTate,
                    profile: {
                      ...prevSTate.profile,
                      gender
                    }
                  }))}
                  mode="dropdown"
                >
                  {genderOptions.map(gender => (
                    <Picker.Item
                      key={`gender-${gender.value}`}
                      label={gender.label}
                      value={gender.value}
                    />
                  ))}
                </Picker>
              </View>
            </View>
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionHeaderText}>Age</Text>
              </View>
              <View style={styles.sectionBody}>
                <View style={cs.row}>
                  <NumericInput
                    onChange={age => this.setState(prevSTate => ({
                      ...prevSTate,
                      profile: {
                        ...prevSTate.profile,
                        age
                      }
                    }))}
                    type={'up-down'}
                    style={cs.fieldInput}
                    minValue={12}
                    initValue={Number.parseInt(profile.age)}
                  />
                  <View style={styles.toyo}>
                    <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>y.o</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
          <TouchableOpacity
            style={[cs.formButton, {
              marginTop: 5,
              marginBottom: 5,
              backgroundColor: c.soft_gray
            },
            this.state.buttonDisabled ? styles.buttonDefaultDisabled : null]}
            activeOpacity={.7}
            onPress={() => this._submit()}
          >
            {this.state.isLoading ? (
              <Image source={spinner} style={styles.loading} />
            ) : (
              <Text style={[cs.formButtonLabel, {
                color: c.primary,
                fontSize: 16
              }]}>SAVE</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 15
  },
  loading: {
    width: 24,
    height: 24
  },
  buttonDefaultDisabled: {
    backgroundColor: '#D6D7D7'
  },
  buttonDefaultTextDisabled: {
    color: '#ADADAD'
  },
  photoContainer: {
    padding: 5,
    alignItems: 'center'
  },
  pp: {
    width: 150,
    height: 150,
    borderRadius: 150
  },
  bioContainer: {
    flexDirection: 'column',
    paddingTop: 10
  },
  name: {
    marginTop: 8,
    fontSize: 16,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  sectionHeader: {
    padding: 10,
    backgroundColor: c.primary,
    borderRadius: 5
  },
  sectionHeaderText: {
    fontFamily: 'VAGRounded_BT',
    fontSize: 16,
    color: c.white
  },
  section: {
    marginBottom: 15
  },
  sectionBody: {
    flex: 1,
    paddingVertical: 10
  },
  sectionBodyText: {
    fontSize: 18,
    fontFamily: 'VAGRoundedBT-Regular',
    color: c.black
  },
  toyo: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10
  }
});

export default EditProfileScreen;