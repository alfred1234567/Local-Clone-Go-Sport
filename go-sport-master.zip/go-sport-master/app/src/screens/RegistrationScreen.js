import React, {Component} from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  ToastAndroid,
  StatusBar
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import NumericInput from 'react-native-numeric-input';
import RadioForm, {
  RadioButton,
  RadioButtonInput,
  RadioButtonLabel
} from 'react-native-simple-radio-button';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import API from './../api';
import { isEmpty } from "./../helpers";
import spinner from "./../../assets/loading.gif";

const GenderOptions = [
  {
    label: "Male",
    value: "male"
  },
  {
    label: "Female",
    value: "female"
  }
];

class RegistrationScreen extends Component {
  state = {
    userId: "",
    email: "",
    name: "",
    password: "",
    rePassword: "",
    phone: "",
    gender: -1,
    age: 24,
    buttonDisabled: false,
    isLoading: false,
  };
  componentWillUnmount() {
    clearTimeout(this._timeout);
  }
  _validateEmail(email) {
    return /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'REGISTER'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderForm() {
    const { gender } = this.state;

    return (
      <View style={cs.boxForm}>
        <Text style={cs.formLabel}>Please fill out the form below.</Text>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-at"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            placeholder={'New User ID'}
            underlineColorAndroid={'transparent'}
            onChangeText={userId => this.setState({ userId })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-mail"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            placeholder={'Email Address'}
            underlineColorAndroid={'transparent'}
            onChangeText={email => this.setState({ email })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-contact"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            placeholder={'Full Name'}
            underlineColorAndroid={'transparent'}
            onChangeText={name => this.setState({ name })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-lock"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            secureTextEntry={true}
            placeholder={'New Password'}
            underlineColorAndroid={'transparent'}
            onChangeText={password => this.setState({ password })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-lock"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            secureTextEntry={true}
            placeholder={'Confirm Your Password'}
            underlineColorAndroid={'transparent'}
            onChangeText={rePassword => this.setState({ rePassword })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-contacts"
            size={28}
            color={c.dark_gray}
          />
          <RadioForm
            formHorizontal={true}
            animation={true}
          >
            {GenderOptions.map((obj, i) => {
              var _onPress = (value, index) => {
                this.setState({
                  gender: index
                });
              };
              return (
                <RadioButton
                  labelHorizontal={true}
                  key={i}
                >
                  <RadioButtonInput
                    obj={obj}
                    index={i}
                    isSelected={gender === i}
                    onPress={_onPress}
                    borderWidth={2}
                    buttonInnerColor={'#F93A2C'}
                    buttonOuterColor={gender === i ? '#F93A2C' : '#BDBDBD'}
                    buttonSize={10}
                    buttonOuterSize={20}
                    buttonStyle={{}}
                    buttonWrapStyle={[i > 0 ? { marginLeft: 10 } : null]}
                  />
                  <RadioButtonLabel
                    obj={obj}
                    index={i}
                    labelHorizontal={true}
                    onPress={_onPress}
                    labelStyle={{ fontSize: 12, color: gender === i ? '#F93A2C' : '#6A737D' }}
                    labelWrapStyle={{}}
                  /> 
                </RadioButton>
              );
            })}
          </RadioForm>
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-call"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            style={cs.fieldInput}
            placeholder={'Phone Number'}
            underlineColorAndroid={'transparent'}
            keyboardType={'phone-pad'}
            onChangeText={phone => this.setState({ phone })}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={cs.fieldIcon}
            name="ios-person"
            size={28}
            color={c.dark_gray}
          />
          <View style={[cs.row, { paddingVertical: 10 }]}>
            <NumericInput
              onChange={age => this.setState({ age })}
              type={'up-down'}
              style={cs.fieldInput}
              minValue={12}
              initValue={this.state.age}
            />
            <View style={styles.toyo}>
              <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>y.o</Text>
            </View>
          </View>
        </View>
        <TouchableOpacity
          style={[cs.formButton, {backgroundColor: c.primary}, this.state.buttonDisabled ? styles.buttonDefaultDisabled : null]}
          activeOpacity={.7}
          onPress={() => this._register()}
          disabled={this.state.buttonDisabled}
        >
          {this.state.isLoading ? (
            <Image source={spinner} style={styles.loading} />
          ) : (
            <Text style={[cs.formButtonLabel, this.state.buttonDisabled ? styles.buttonDefaultTextDisabled : null]}>REGISTER</Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[cs.formButton, {
            marginTop: 10,
            backgroundColor: c.material_orange
          }]}
          activeOpacity={.7}
          onPress={() => this.props.navigation.goBack()}
        >
          <Text style={cs.formButtonLabel}>I ALREADY HAVE AN ACCOUNT</Text>
        </TouchableOpacity>
      </View>
    );
  }
  _register() {
    if (this.state.isLoading) return;

    const {
      userId,
      name,
      email,
      password,
      rePassword,
      gender,
      phone,
      age
    } = this.state;

    // Validate user's input
    if (isEmpty(userId)) {
      return ToastAndroid.show("User ID can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(email)) {
      return ToastAndroid.show("Email can't be empty.", ToastAndroid.SHORT);
    } else if (!this._validateEmail(email)) {
      return ToastAndroid.show("Email format is not valid.", ToastAndroid.SHORT);
    } else if (isEmpty(name)) {
      return ToastAndroid.show("Name can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(password)) {
      return ToastAndroid.show("Password can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(rePassword)) {
      return ToastAndroid.show("Please re-type your password.", ToastAndroid.SHORT);
    } else if (gender < 0) {
      return ToastAndroid.show("Please choose your gender.", ToastAndroid.SHORT);
    } else if (isEmpty(phone)) {
      return ToastAndroid.show("Phone can't be empty.", ToastAndroid.SHORT);
    } else if (password != rePassword) {
      return ToastAndroid.show("Password confirmation must match the previous entry.", ToastAndroid.SHORT);
    }

    this.setState({
      buttonDisabled: true,
      isLoading: true
    });

    this._timeout = setTimeout(() => {
      API.post(`register`, JSON.stringify({
        user_id: userId,
        name,
        email,
        password,
        gender: 0 ? 'male' : 'female',
        phone,
        age
      }))
        .then(res => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (res.data.success) {
                ToastAndroid.show("Registration success", ToastAndroid.SHORT);
                this.props.navigation.goBack();
              } else {
                ToastAndroid.show(res.data.error.message, ToastAndroid.SHORT);
              }
            }
          );
        })
        .catch(error => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }, 2000);
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={[cs.fl1, {backgroundColor: c.material_gray}]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={'handled'}
        >
          <KeyboardAvoidingView style={[cs.fl1, styles.container]} enabled>
            {this._renderForm()}
          </KeyboardAvoidingView>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 25,
    paddingVertical: 15
  },
  loading: {
    width: 24,
    height: 24
  },
  buttonDefaultDisabled: {
    backgroundColor: '#D6D7D7'
  },
  buttonDefaultTextDisabled: {
    color: '#ADADAD'
  },
  toyo: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10
  }
});

export default RegistrationScreen;