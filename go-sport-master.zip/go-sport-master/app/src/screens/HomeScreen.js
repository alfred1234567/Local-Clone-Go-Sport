import React, {Component} from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  ToastAndroid,
  AsyncStorage,
  StatusBar
} from 'react-native';
import DrawerLayout from 'react-native-drawer-layout';
import Icon from 'react-native-vector-icons/Ionicons';
import Slideshow from 'react-native-slideshow';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import {menuItems, slideshowItems} from './../constants';
import API from './../api';
import { isEmpty } from "./../helpers";
import UserStore from "./../mobx/userStore";
import spinner from "./../../assets/loading.gif";

class HomeScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      activeMenu: menuItems[0],
      position: 0,
      interval: null,
      buttonDisabled: false,
      isLoading: false,
      isLoggedIn: false,
      sliders: [],

      login_userId: "",
      login_userPassword: ""
    };
    this._renderDrawer = this._renderDrawer.bind(this);
  }
  componentWillMount() {
    this._loadUserData().done();
    this._loadSliders();
    this.setState({
      interval: setInterval(() => {
        this.setState({
          position: this.state.position === slideshowItems.length ? 0 : this.state.position + 1
        });
      }, 5000)
    });
  }
  componentWillUnmount() {
    clearTimeout(this._timeout);
    clearInterval(this.state.interval);
  }
  _loadSliders() {
    API.get(`sliders`)
      .then(res => {
        if (res.data.success) {
          const { sliders } = res.data.success;

          let data = [];
          for (let i = 0; i < sliders.length; i++) {
            data.push({ url: sliders[i].file });
          }
          
          this.setState({
            sliders: data
          });
        }
      })
      .catch(error => {
        if (error.response) {
          if (error.response.data.message) {
            return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
          } else {
            return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
          }
        }
      });
  }
  _renderDrawer() {
    const user = JSON.parse(UserStore.user);

    return (
      <View style={styles.drWrapper}>
        <View style={styles.drRow}>
          <Icon
            name="ios-person"
            size={30}
            color={c.white}
            style={cs.transparent}
          />
          <Text style={[styles.menuText, { fontSize: 18 }]}>{user ? user.name : 'Guest'}</Text>
        </View>
        {menuItems.map((item, i) => (!user && i === 1) 
          ? null 
          : this._renderMenu(item, i))}
      </View>
    );
  }
  _renderToolbar() {
    return <Toolbar
      title={'HOME'}
      _openDrawer={() => this._drawerRef.openDrawer()}
      _hasNotification
    />;
  }
  _renderMenu(item, i) {
    const { activeMenu } = this.state;
    const isMenuActive = activeMenu
      ? activeMenu.key == menuItems.key
      : null;
    
    return <TouchableOpacity
      activeOpacity={.7}
      style={[styles.drRow, { backgroundColor: c.soft_gray },
        isMenuActive ? styles.menuActive : null
      ]}
      key={`${item.key}-${i}`}
      onPress={() => this._changeActiveMenu(item)}
    >
      <Icon
        name={item.icon}
        size={30}
        color={c.dark_gray}
        style={cs.transparent}
      />
      <Text style={[styles.menuText, { color: c.dark_gray }]}>{item.name.toUpperCase()}</Text>
    </TouchableOpacity>;
  }
  _renderLoginForm() {
    if (this.state.isLoggedIn) {
      const user = JSON.parse(UserStore.user);
      if (user) {
        return (
          <View style={styles.dashboard}>
            <Text style={styles.dashboardWelcomeText}>Welcome, {user.name}</Text>
            <TouchableOpacity
              activeOpacity={.7}
              style={styles.buttonLogin}
              onPress={() => this.props.navigation.navigate('Category')}
            >
              <Text style={styles.buttonLoginLabel}>START</Text>
            </TouchableOpacity>
          </View>
        );
      }
    }

    return (
      <View style={styles.loginBox}>
        <Text style={styles.loginLabel}>Login</Text>
        <View style={styles.loginForm}>
          <View style={styles.loginFormGroup}>
            <Icon
              style={styles.loginFieldIcon}
              name="ios-person"
              size={28}
              color={c.dark_gray}
            />
            <TextInput
              style={styles.loginFieldInput}
              placeholder={'User ID'}
              underlineColorAndroid={'transparent'}
              value={this.state.login_userId}
              onChangeText={(login_userId) => this.setState({ login_userId })}
            />
          </View>
          <View style={styles.loginFormGroup}>
            <Icon
              style={styles.loginFieldIcon}
              name="ios-lock"
              size={28}
              color={c.dark_gray}
            />
            <TextInput
              style={styles.loginFieldInput}
              secureTextEntry={true}
              placeholder={'Password'}
              underlineColorAndroid={'transparent'}
              value={this.state.login_userPassword}
              onChangeText={(login_userPassword) => this.setState({ login_userPassword })}
            />
          </View>
          <View style={styles.forgotPassword}>
            <TouchableOpacity
              activeOpacity={.7}
              onPress={() => this.props.navigation.navigate('ForgotPassword')}
            >
              <Text style={styles.forgotPasswordText}>Forgot your password?</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={[styles.buttonLogin, this.state.buttonDisabled ? styles.buttonLoginDisabled : null]}
            activeOpacity={.7}
            onPress={() => this._login()}
            disabled={this.state.buttonDisabled}
          >
            {this.state.isLoading ? (
              <Image source={spinner} style={styles.loading} />
            ) : (
              <Text style={[styles.buttonLoginLabel, this.state.buttonDisabled ? styles.buttonLoginTextDisabled : null]}>LOGIN</Text>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.buttonLogin, {
              marginTop: 10,
              backgroundColor: c.dark_gray
            }]}
            activeOpacity={.7}
            onPress={() => this.props.navigation.navigate('Registration')}
          >
            <Text style={styles.buttonLoginLabel}>REGISTER</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  _changeActiveMenu(menu) {
    this._drawerRef.closeDrawer();

    switch (menu.key) {
      case 'home': {
        break;
      }
      case 'profile': {
        this.props.navigation.navigate('Profile');
        break;
      }
      case 'about_us': {
        this.props.navigation.navigate('About');
        break;
      }
      case 'contact_us': {
        break;
      }
    }
  }
  async _login() {
    if (this.state.isLoading) return;

    const {
      login_userId,
      login_userPassword
    } = this.state;

    // Validate user's input
    if (isEmpty(login_userId)) {
      return ToastAndroid.show("User ID can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(login_userPassword)) {
      return ToastAndroid.show("Password can't be empty.", ToastAndroid.SHORT);
    }

    this.setState({
      buttonDisabled: true,
      isLoading: true
    });

    this._timeout = setTimeout(() => {
      API.post(`login`, JSON.stringify({ user_id: login_userId, password: login_userPassword }))
        .then(async res => {
          this.setState(
            {
              isLoggedIn: true,
              buttonDisabled: false,
              isLoading: false
            },
            async () => {
              if (res.data.success) {
                const { user } = res.data.success;
                const { id, role_id, name, email, user_id } = user;
                const strUser = JSON.stringify(
                  {
                    id,
                    role_id,
                    email,
                    name,
                    user_id
                  }
                );
                UserStore.updateUser(strUser);
                await AsyncStorage.setItem('user', strUser);
                ToastAndroid.show(`Welcome, ${name}`, ToastAndroid.SHORT);
                this.props.navigation.navigate('Category');
              } else {
                ToastAndroid.show(res.data.error.message, ToastAndroid.SHORT);
              }
            }
          );
        })
        .catch(error => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }, 2000);
  }
  async _loadUserData() {
    try {
      const user = await AsyncStorage.getItem('user');
      if (user) {
        this.setState({
          isLoggedIn: true
        }, () => UserStore.updateUser(user));
      }
    } catch (error) {
      ToastAndroid.show('Failed to load user data', ToastAndroid.SHORT);
    }
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        <DrawerLayout
          ref={(ref) => this._drawerRef = ref}
          drawerWidth={250}
          drawerPosition={DrawerLayout.positions.Left}
          renderNavigationView={this._renderDrawer}
        >
          {this._renderToolbar()}
          <KeyboardAvoidingView style={cs.fl1} enabled>
            <ScrollView
              style={[cs.fl1, styles.container]}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps={'handled'}
            >
              <Slideshow
                dataSource={this.state.sliders}
                position={this.state.position}
                onPositionChanged={position => this.setState({ position })}
                indicatorSelectedColor={c.primary}
              />
              <View style={styles.bodyContainer}>
                {this._renderLoginForm()}
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </DrawerLayout>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: c.material_gray
  },

  drWrapper: {
    flex: 1,
    backgroundColor: c.soft_gray
  },
  drRow: {
    backgroundColor: c.dark_gray,
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15
  },

  menuText: {
    paddingLeft: 15,
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 12,
    color: c.white
  },

  bodyContainer: {
    paddingHorizontal: 25,
    paddingVertical: 15
  },

  dashboard: {
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center'
  },
  dashboardWelcomeText: {
    fontSize: 18,
    fontFamily: 'VAGRoundedBT-Regular'
  },

  loginBox: {
    backgroundColor: c.white,
    paddingHorizontal: 30,
    paddingVertical: 20,
    elevation: 2
  },
  loginLabel: {
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 14,
    fontWeight: '500',
    color: c.black
  },
  loginForm: {
    flexDirection: 'column',
    marginBottom: 10
  },
  loginFormGroup: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderBottomWidth: 1,
    borderBottomColor: c.dark_gray
  },
  loginFieldIcon: {
    paddingVertical: 5,
    paddingRight: 5
  },
  loginFieldInput: {
    flex: 1,
    height: 40,
    paddingVertical: 10,
    backgroundColor: 'transparent',
    color: c.black
  },
  forgotPassword: {
    marginTop: 15,
    alignItems: 'flex-end',
    justifyContent: 'center'
  },
  forgotPasswordText: {
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 16
  },
  buttonLogin: {
    backgroundColor: c.primary,
    marginTop: 15,
    padding: 14,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 1
  },
  buttonLoginLabel: {
    color: c.white,
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 14
  },
  buttonLoginDisabled: {
    backgroundColor: '#D6D7D7'
  },
  buttonLoginTextDisabled: {
    color: '#ADADAD'
  }
});

export default HomeScreen;