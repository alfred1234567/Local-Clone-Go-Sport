import React, {Component} from 'react';
import {
  StyleSheet,
  FlatList,
  View,
  Text,
  Image,
  StatusBar
} from 'react-native';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import CategoryListItem from './../components/CategoryListItem';
import {categoryList} from './../constants';
import API from "./../api";
import spinner from "./../../assets/loading.gif";

class CategoryListScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      category: this.props.navigation.getParam('category', null),
      spots: [],
      isLoading: false,
    };
  }
  componentWillMount() {
    this._loadSpots();
  }
  componentWillUnmount() {
    this._timeout && clearTimeout(this._timeout);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={this.state.category ? this.state.category.name : 'Loading...'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderList() {
    const { isLoading, spots } = this.state;

    if (isLoading) {
      return (
        <View style={styles.spotsLoadingContainer}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    return (
      <FlatList
        contentContainerStyle={[{ padding: 14, backgroundColor: c.white }, categoryList.length === 0 && { paddingTop: 10, justifyContent: 'center', alignItems: 'center' }]}
        showsVerticalScrollIndicator={false}
        data={spots}
        keyExtractor={(item, index) => `catg-${item.id}`}
        renderItem={this._renderListItem}
        ListEmptyComponent={(
          <View style={{ alignItems: 'center' }}>
            <Text>List is empty</Text>
          </View>
        )}
      />
    );
  }
  _renderListItem = ({item, index}) => (
    <CategoryListItem
      item={item}
      navigation={this.props.navigation}
      overrideStyle={index != categoryList.length - 1 && {marginBottom: 16}}
    />
  );
  _loadSpots() {
    this.setState({
      isLoading: true
    });

    const { category } = this.state;

    if (category) {

      API.get(`spots/${category.id}`)
        .then(res => {
          if (res.data.success) {
            const { spots } = res.data.success;
            
            this.setState({
              isLoading: false,
              spots
            });
          }
        })
        .catch(error => {
          this.setState(
            {
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }
  }
  render() {
    return (
      <View style={[cs.fl1, { backgroundColor: c.white }]}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        {this._renderList()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  spotsLoadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  loading: {
    width: 32,
    height: 32
  }
});

export default CategoryListScreen;