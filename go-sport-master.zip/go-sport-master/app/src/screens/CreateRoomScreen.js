import React, {Component} from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  DatePickerAndroid,
  TimePickerAndroid,
  ToastAndroid,
  Picker,
  StatusBar
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import FA from 'react-native-vector-icons/FontAwesome';
import NumericInput from 'react-native-numeric-input';
import moment from 'moment';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import { isEmpty } from "./../helpers";
import API from "./../api";
import spinner from "./../../assets/loading.gif";

const difficultyOptions = [
  {
    id: 1,
    label: "Beginner",
    value: "beginner"
  },
  {
    id: 2,
    label: "Normal",
    value: "normal"
  },
  {
    id: 3,
    label: "Professional",
    value: "professional"
  }
];

const genderOptions = [
  {
    id: 1,
    label: "Male",
    value: "male"
  },
  {
    id: 2,
    label: "Female",
    value: "female"
  },
  {
    id: 3,
    label: "Both",
    value: "both"
  }
];

const PlayerInfo = ({ idx, item, updatePlayerInfo }) => (
  <View style={[cs.row, { marginBottom: 10, alignItems: 'center' }]}>
    <View style={cs.fl1}>
      <TextInput
        onChangeText={name => updatePlayerInfo(idx, {
          ...item,
          name
        })}
        value={item.name}
        style={cs.fieldInput}
        placeholder={'Name'}
        underlineColorAndroid={'transparent'}
      />
    </View>
    <View style={[cs.fl2, { paddingHorizontal: 5 }]}>
      <View style={cs.row}>
        <NumericInput
          onChange={age => updatePlayerInfo(idx, {
            ...item,
            age
          })}
          type={'up-down'}
          style={cs.fieldInput}
          minValue={12}
          initValue={item.age}
        />
        <View style={styles.toyo}>
          <Text>y.o</Text>
        </View>
      </View>
    </View>
    <View style={[cs.fl2, { paddingHorizontal: 5 }]}>
      <Picker
        selectedValue={item.gender}
        style={cs.fl1}
        onValueChange={(gender, genderIndex) => updatePlayerInfo(idx, {
          ...item,
          gender
        })}
        mode="dropdown"
      >
        {genderOptions.filter(gender => gender.value !== 'both')
          .map(gender => (
            <Picker.Item
              key={`gender-${gender.value}`}
              label={gender.label}
              value={gender.value}
            />
          ))}
      </Picker>
    </View>
  </View>
);

class CreateRoomScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      courtId: this.props.navigation.getParam('courtId', null),
      bookDate: "",
      bookTime: "",
      bookDuration: 1,
      courtNumber: 1,
      difficulty: null,
      gender: null,
      minAge: 14,
      maxAge: 30,
      numPlayers: 1,
      players: [
        {
          name: "",
          age: 10,
          gender: "male"
        }
      ],
      buttonDisabled: false,
      isLoading: false,
    };
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'NEW ROOM'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderForm() {
    return (
      <View style={[cs.boxForm, {paddingVertical: 5, elevation: 0}]}>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-calendar"
            size={28}
            color={c.dark_gray}
          />
          <TextInput
            onFocus={this._openDatePicker}
            style={cs.fieldInput}
            placeholder={'Booking Date'}
            underlineColorAndroid={'transparent'}
            value={this.state.bookDate}
          />
        </View>
        <View style={[cs.fl1, cs.row, { backgroundColor: c.red }]}>
          <View style={[cs.fl1, cs.formGroup, { marginRight: 10 }]}>
            <Icon
              style={[cs.fieldIcon, { paddingRight: 8 }]}
              name="md-clock"
              size={28}
              color={c.dark_gray}
            />
            <TextInput
              onFocus={this._openTimePicker}
              style={cs.fieldInput}
              placeholder={'Booking Time'}
              underlineColorAndroid={'transparent'}
              value={this.state.bookTime}
            />
          </View>
          <View style={[cs.fl1, cs.formGroup]}>
            <View style={cs.fl1}>
              <TextInput
                style={[cs.fieldInput, { paddingRight: 8 }]}
                placeholder={'Dur.'}
                underlineColorAndroid={'transparent'}
              />
            </View>
            <View style={cs.fl2}>
              <Text>hours</Text>
            </View>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <FA
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="sort-numeric-asc"
            size={28}
            color={c.dark_gray}
          />
          <NumericInput
            type={'up-down'}
            onChange={courtNumber => this.setState({courtNumber})}
            style={cs.fieldInput}
            placeholder={'Court Number'}
            underlineColorAndroid={'transparent'}
            minValue={1}
            initValue={this.state.courtNumber}
          />
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-trending-up"
            size={28}
            color={c.dark_gray}
          />
          <View style={cs.fl1}>
            <Picker
              selectedValue={this.state.difficulty}
              style={cs.fl1}
              onValueChange={(difficulty, difficultyIndex) => this.setState({difficulty})}
              mode="dropdown"
            >
              {difficultyOptions.map(diff => (
                <Picker.Item
                  key={`diff-${diff.value}`}
                  label={diff.label}
                  value={diff.value}
                />
              ))}
            </Picker>
          </View>
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-body"
            size={28}
            color={c.dark_gray}
          />
          <View style={cs.fl1}>
            <Picker
              selectedValue={this.state.gender}
              style={cs.fl1}
              onValueChange={(gender, genderIndex) => this.setState({gender})}
              mode="dropdown"
            >
              {genderOptions.map(gender => (
                <Picker.Item
                  key={`gender-${gender.value}`}
                  label={gender.label}
                  value={gender.value}
                />
              ))}
            </Picker>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-person"
            size={28}
            color={c.dark_gray}
          />
          <View style={cs.row}>
            <NumericInput
              type={'up-down'}
              onChange={minAge => this.setState({minAge})}
              style={cs.fieldInput}
              minValue={12}
              initValue={this.state.minAge}
            />
            <View style={styles.toyo}>
              <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>to</Text>
            </View>
            <NumericInput
              type={'up-down'}
              onChange={maxAge => this.setState({maxAge})}
              style={cs.fieldInput}
              minValue={12}
              initValue={this.state.maxAge}
            />
            <View style={styles.toyo}>
              <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>y.o</Text>
            </View>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-people"
            size={28}
            color={c.dark_gray}
          />
          <NumericInput
            type={'up-down'}
            onChange={numPlayers => this._updateNumPlayers(numPlayers)}
            style={cs.fieldInput}
            value={this.state.numPlayers}
            minValue={1}
            initValue={this.state.numPlayers}
          />
        </View>
        <View style={styles.playerListContainer}>
          <View style={{ padding: 8 }}>
            <Text style={{ fontSize: 17, fontFamily: 'VAGRoundedBT-Regular' }}>Player Details</Text>
          </View>
          {this.state.players.map((player, idx) => (
            <PlayerInfo
              key={`player-${idx}`}
              idx={idx}
              item={player}
              updatePlayerInfo={(idx, newValue) => this._updatePlayerInfo(idx, newValue)}
            />
          ))}
        </View>
        <TouchableOpacity
          style={[cs.formButton, {marginTop: 20, backgroundColor: c.primary_darker}, this.state.buttonDisabled ? styles.buttonDefaultDisabled : null]}
          activeOpacity={.7}
          onPress={() => this._submit()}
          disabled={this.state.buttonDisabled}
        >
          {this.state.isLoading ? (
            <Image source={spinner} style={styles.loading} />
          ) : (
            <Text style={[cs.formButtonLabel, this.state.buttonDisabled ? styles.buttonDefaultTextDisabled : null]}>CREATE</Text>
          )}
        </TouchableOpacity>
      </View>
    );
  }
  _openDatePicker = async (stateKey, options) => {
    try {
      const {action, year, month, day} = await DatePickerAndroid.open({
        date: new Date()
      });
      if (action !== DatePickerAndroid.dismissedAction) {
        const date = new Date(year, month, day);
        this.setState({
          bookDate: moment(date).format("YYYY-MM-DD")
        });
      }
    } catch ({code, message}) {
      console.warn('Cannot open date picker', message);
    }
  }
  _openTimePicker = async (stateKey, options) => {
    try {
      const {action, hour, minute} = await TimePickerAndroid.open({
        hour: 1,
        minute: 0,
        is24Hour: true
      });
      if (action !== TimePickerAndroid.dismissedAction) {
        this.setState({
          bookTime: `${hour}:${minute}`
        });
      }
    } catch ({code, message}) {
      console.warn('Cannot open time picker', message);
    }
  }
  _updateNumPlayers(newValue) {
    const { players } = this.state;

    if (this.state.numPlayers < newValue) { // adding
      players.push({
        name: "",
        age: 10,
        gender: "male"
      })
    } else { // removing
      players.pop();
    }

    this.setState({numPlayers: players.length, players});
  }
  _updatePlayerInfo = (idx, newValue) => {
    const { players } = this.state;
    players[idx] = newValue;

    this.setState({ players });
  };
  _submit() {
    if (this.state.isLoading) return;

    const {
      courtId,
      bookDate,
      bookTime,
      bookDuration,
      courtNumber,
      difficulty,
      gender,
      minAge,
      maxAge,
      numPlayers,
      players
    } = this.state;

    // Validate user's input
    if (isEmpty(bookDate)) {
      return ToastAndroid.show("Date can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(bookTime)) {
      return ToastAndroid.show("Time can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(bookDuration)) {
      return ToastAndroid.show("Duration can't be empty.", ToastAndroid.SHORT);
    } else if (isEmpty(courtNumber)) {
      return ToastAndroid.show("Court number must be chosen.", ToastAndroid.SHORT);
    } else if (isEmpty(difficulty)) {
      return ToastAndroid.show("Difficulty must be chosen.", ToastAndroid.SHORT);
    } else if (isEmpty(gender)) {
      return ToastAndroid.show("Gender must be chosen.", ToastAndroid.SHORT);
    } else if (isEmpty(minAge)) {
      return ToastAndroid.show("Min. age must be chosen.", ToastAndroid.SHORT);
    } else if (isEmpty(maxAge)) {
      return ToastAndroid.show("Max. age must be chosen.", ToastAndroid.SHORT);
    } else if (isEmpty(numPlayers)) {
      return ToastAndroid.show("Num. of players can't be empty.", ToastAndroid.SHORT);
    }

    this.setState({
      buttonDisabled: true,
      isLoading: true
    });

    this._timeout = setTimeout(() => {
      API.post(`court/${courtId}/room`, JSON.stringify({
        dt: `${bookDate} ${bookTime}`,
        duration: bookDuration,
        court_number: courtNumber,
        slot: numPlayers,
        level: difficulty,
        gender,
        min_age: minAge,
        max_age: maxAge,
        players: JSON.stringify(players)
      }))
        .then(res => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (res.data.success) {
                ToastAndroid.show("Room has been created", ToastAndroid.SHORT);
                this.props.navigation.goBack();
              } else {
                ToastAndroid.show(res.data.error.message, ToastAndroid.SHORT);
              }
            }
          );
        })
        .catch(error => {
          this.setState(
            {
              buttonDisabled: false,
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }, 2000);
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={[cs.fl1, {backgroundColor: c.white}]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={'handled'}
        >
          <KeyboardAvoidingView style={cs.fl1} enabled>
            {this._renderForm()}
          </KeyboardAvoidingView>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  toyo: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10
  },
  playerListContainer: {
    backgroundColor: c.soft_gray,
    marginTop: 12,
    padding: 8,
    borderRadius: 10
  },
  loading: {
    width: 24,
    height: 24
  },
  buttonDefaultDisabled: {
    backgroundColor: '#D6D7D7'
  },
  buttonDefaultTextDisabled: {
    color: '#ADADAD'
  }
});

export default CreateRoomScreen;