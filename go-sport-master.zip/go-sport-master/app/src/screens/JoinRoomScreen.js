import React, {Component} from 'react';
import {
  StyleSheet,
  KeyboardAvoidingView,
  ScrollView,
  View,
  Text,
  Image,
  TextInput,
  TouchableOpacity,
  ToastAndroid,
  Picker,
  StatusBar
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import FA from 'react-native-vector-icons/FontAwesome';
import NumericInput from 'react-native-numeric-input';
import moment from 'moment';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import API from "./../api";
import spinner from "./../../assets/loading.gif";

const genderOptions = [
  {
    id: 1,
    label: "Male",
    value: "male"
  },
  {
    id: 2,
    label: "Female",
    value: "female"
  }
];

const PlayerJoinRequestInfo = ({ idx, item, updatePlayerRequest, removePlayerRequest }) => (
  <View style={[cs.row, styles.playerRow]}>
    <View style={cs.fl1}>
      <TextInput
        onChangeText={name => updatePlayerRequest(idx, {
          ...item,
          name
        })}
        value={item.name}
        style={cs.fieldInput}
        placeholder={'Name'}
        underlineColorAndroid={'transparent'}
      />
    </View>
    <View style={cs.fl2}>
      <NumericInput
        onChange={age => updatePlayerRequest(idx, {
          ...item,
          age
        })}
        type={'up-down'}
        style={cs.fieldInput}
        minValue={12}
        initValue={item.age}
      />
    </View>
    <View style={cs.fl2}>
      <Picker
        selectedValue={item.gender}
        style={cs.fl1}
        onValueChange={(gender, genderIndex) => updatePlayerRequest(idx, {
          ...item,
          gender
        })}
        mode="dropdown"
      >
        {genderOptions.map(gender => (
          <Picker.Item
            key={`gender-${gender.value}`}
            label={gender.label}
            value={gender.value}
          />
        ))}
      </Picker>
    </View>
    <View style={[cs.fl05, { alignItems: 'center' }]}>
      <TouchableOpacity
        activeOpacity={.7}
        onPress={() => removePlayerRequest(idx)}
      >
        <Icon
          name="ios-close"
          size={28}
          color={c.primary_darker}
        />
      </TouchableOpacity>
    </View>
  </View>
);

const PlayerJoinedInfo = ({item}) => (
  <View style={[cs.row, styles.playerRow]}>
    <View style={cs.fl1}>
      <Text style={styles.valueText}>{item.name}</Text>
    </View>
    <View style={cs.fl1}>
      <View style={cs.row}>
        <Text style={styles.valueText}>{item.age}</Text>
        <View style={styles.toyo}>
          <Text style={styles.valueText}>y.o</Text>
        </View>
      </View>
    </View>
    <View style={cs.fl1}>
      <Text style={styles.valueText}>{item.gender}</Text>
    </View>
  </View>
);

class JoinRoomScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      roomId: this.props.navigation.getParam('roomId', null),
      details: null,
      isLoading: false,
      joinRequests: 1,
      newPlayers: [
        {
          name: "",
          age: 10,
          gender: "male"
        }
      ],
      buttonDisabled: false,
      isLoadingSubmit: false
    };
  }
  componentWillMount() {
    this._loadDetails();
  }
  componentWillUnmount() {
    this._timeout && clearTimeout(this._timeout);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'JOIN ROOM'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderPaidStatus() {
    const { isLoading, details } = this.state;

    if (isLoading) {
      return (
        <View style={{ backgroundColor: c.white, alignItems: 'center', padding: 15 }}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    return (
      <View style={[styles.paidOffLabel, details.paid ? '' : {backgroundColor: c.primary_darker}]}>
        <Text style={styles.paidOffLabelText}>{details.paid ? 'PAID' : 'WAITING FOR PAYMENT'}</Text>
      </View>
    );
  }
  _renderAddPlayersSection() {
    let requests = [];
    for (let i = 0; i < this.state.newPlayers.length; i++) {
      requests.push(
        <PlayerJoinRequestInfo
          key={`player-${i}`}
          idx={i}
          item={this.state.newPlayers[i]}
          updatePlayerRequest={(idx, newValue) => this._updatePlayerRequest(idx, newValue)}
          removePlayerRequest={idx => this._removePlayerRequest(idx)}
        />
      );
    }

    return (
      <View style={styles.playerListContainer}>
        <View style={{ padding: 8 }}>
          <Text style={styles.playerListHeading}>Add Players</Text>
        </View>
        <View style={[cs.row, styles.playerRow]}>
          <View style={cs.fl1}>
            <Text style={[styles.playerListHeading, { fontSize: 14 }]}>Name</Text>
          </View>
          <View style={cs.fl1}>
            <Text style={[styles.playerListHeading, { fontSize: 14 }]}>Age</Text>
          </View>
          <View style={cs.fl1}>
            <Text style={[styles.playerListHeading, { fontSize: 14 }]}>Gender</Text>
          </View>
          <View style={cs.fl2}>
            <NumericInput
              type={'up-down'}
              onChange={joinRequests => this._updateNumNewPlayers(joinRequests)}
              style={cs.fieldInput}
              minValue={1}
              initValue={this.state.joinRequests}
            />
          </View>
        </View>
        {requests}
      </View>
    );
  }
  _renderForm() {
    const { isLoading, details } = this.state;

    if (isLoading) {
      return (
        <View style={styles.detailsLoadingContainer}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    const players = details.players != null ? JSON.parse(details.players) : [];

    let playerList = [];
    for (let i = 0; i < this.state.joinedPlayers; i++) {
      playerList.push(<PlayerJoinedInfo />);
    }

    return (
      <View style={[cs.boxForm, {paddingVertical: 5, elevation: 0}]}>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-calendar"
            size={28}
            color={c.dark_gray}
          />
          <Text style={styles.valueText}>{moment(details.dt).format('ll')}</Text>
        </View>
        <View style={[cs.fl1, cs.row, { backgroundColor: c.red }]}>
          <View style={[cs.fl1, cs.formGroup, { marginRight: 10 }]}>
            <Icon
              style={[cs.fieldIcon, { paddingRight: 8 }]}
              name="md-clock"
              size={28}
              color={c.dark_gray}
            />
            <Text style={styles.valueText}>{moment(details.dt).format('hh:mm a')}</Text>
          </View>
          <View style={[cs.fl1, cs.formGroup]}>
            <View style={[cs.fl1, { alignItems: 'center' }]}>
              <Text style={styles.valueText}>2</Text>
            </View>
            <View style={cs.fl3}>
              <Text>hours</Text>
            </View>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <FA
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="sort-numeric-asc"
            size={28}
            color={c.dark_gray}
          />
          <Text style={styles.valueText}>{details.court_number}</Text>
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-trending-up"
            size={28}
            color={c.dark_gray}
          />
          <View style={cs.fl1}>
            <Text style={styles.valueText}>{details.level}</Text>
          </View>
        </View>
        <View style={cs.formGroup}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-body"
            size={28}
            color={c.dark_gray}
          />
          <View style={cs.fl1}>
            <Text style={styles.valueText}>{details.gender}</Text>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-person"
            size={28}
            color={c.dark_gray}
          />
          <View style={[cs.row, { alignItems: 'center' }]}>
            <Text style={styles.valueText}>{details.min_age}</Text>
            <View style={styles.toyo}>
              <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>to</Text>
            </View>
            <Text style={styles.valueText}>{details.max_age}</Text>
            <View style={styles.toyo}>
              <Text style={{ fontSize: 16, fontFamily: 'VAGRoundedBT-Regular' }}>y.o</Text>
            </View>
          </View>
        </View>
        <View style={[cs.formGroup, { paddingBottom: 15 }]}>
          <Icon
            style={[cs.fieldIcon, { paddingRight: 8 }]}
            name="ios-people"
            size={28}
            color={c.dark_gray}
          />
          <Text style={styles.valueText}>{players.length + this.state.joinRequests}</Text>
        </View>
        <View style={styles.playerListContainer}>
          <View style={{ padding: 8 }}>
            <Text style={styles.playerListHeading}>Player Details</Text>
          </View>
          {players.map((player, idx) => <PlayerJoinedInfo key={`joinedplayer-${idx}`} item={player} />)}
        </View>
        {this._renderAddPlayersSection()}
        <TouchableOpacity
          style={[cs.formButton, {marginTop: 20, backgroundColor: c.primary_darker},
            this.state.buttonDisabled ? styles.buttonDefaultDisabled : null]}
          activeOpacity={.7}
          onPress={() => this._submit()}
          disabled={this.state.buttonDisabled}
        >
          {this.state.isLoadingSubmit ? (
            <Image source={spinner} style={styles.loading} />
          ) : (
            <Text style={[cs.formButtonLabel, this.state.buttonDisabled ? styles.buttonDefaultTextDisabled : null]}>JOIN</Text>
          )}
        </TouchableOpacity>
      </View>
    );
  }
  _loadDetails() {
    this.setState({
      isLoading: true
    });

    const { roomId } = this.state;

    if (roomId) {

      API.get(`room/${roomId}/details`)
        .then(res => {
          if (res.data.success) {
            const { room } = res.data.success;
            
            this.setState({
              isLoading: false,
              details: room
            });
          }
        })
        .catch(error => {
          this.setState(
            {
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }
  }
  _updatePlayerRequest = (idx, newValue) => {
    const { newPlayers } = this.state;
    newPlayers[idx] = newValue;

    this.setState({ newPlayers });
  };
  _updateNumNewPlayers(newValue) {
    const { newPlayers } = this.state;

    if (this.state.joinRequests < newValue) { // adding
      newPlayers.push({
        name: "",
        age: 10,
        gender: "male"
      })
    } else { // removing
      newPlayers.pop();
    }

    this.setState({joinRequests: newPlayers.length, newPlayers});
  }
  _removePlayerRequest(index) {
    const { newPlayers } = this.state;

    if (newPlayers.length <= 1)
      return ToastAndroid.show("Min. number of player is 1", ToastAndroid.SHORT);

    newPlayers.splice(index, 1);
    this.setState({newPlayers, joinRequests: newPlayers.length});
  }
  _submit() {
    if (this.state.isLoadingSubmit) return;

    const {
      roomId,
      details,
      newPlayers
    } = this.state;

    this.setState({
      buttonDisabled: true,
      isLoadingSubmit: true
    });

    const previousPlayers = details.players != null ? JSON.parse(details.players) : [];
    this._timeout = setTimeout(() => {
      API.post(`room/${roomId}/join`, JSON.stringify({
        players: JSON.stringify([...previousPlayers, ...newPlayers])
      }))
        .then(res => {
          this.setState(
            {
              buttonDisabled: false,
              isLoadingSubmit: false
            },
            () => {
              if (res.data.success) {
                ToastAndroid.show("Join room success", ToastAndroid.SHORT);
                this.props.navigation.goBack();
              } else {
                ToastAndroid.show(res.data.error.message, ToastAndroid.SHORT);
              }
            }
          );
        })
        .catch(error => {
          this.setState(
            {
              buttonDisabled: false,
              isLoadingSubmit: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }, 2000);
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        {this._renderPaidStatus()}
        <ScrollView
          style={[cs.fl1, {backgroundColor: c.white}]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps={'handled'}
        >
          <KeyboardAvoidingView style={cs.fl1} enabled>
            {this._renderForm()}
          </KeyboardAvoidingView>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  detailsLoadingContainer: {
    paddingTop: 15,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  loading: {
    width: 32,
    height: 32
  },
  paidOffLabel: {
    padding: 10,
    backgroundColor: c.material_green,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 1
  },
  paidOffLabelText: {
    color: c.white,
    fontSize: 15,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  toyo: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10
  },
  playerListContainer: {
    backgroundColor: c.soft_gray,
    marginTop: 12,
    padding: 8,
    borderRadius: 10
  },
  playerRow: {
    marginBottom: 10,
    alignItems: 'center'
  },
  playerListHeading: {
    fontSize: 17,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  valueText: {
    fontSize: 16,
    fontFamily: 'VAGRoundedBT-Regular'
  },
  buttonDefaultDisabled: {
    backgroundColor: '#D6D7D7'
  },
  buttonDefaultTextDisabled: {
    color: '#ADADAD'
  }
});

export default JoinRoomScreen;