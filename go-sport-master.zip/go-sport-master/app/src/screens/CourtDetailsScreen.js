import React, {Component} from 'react';
import {
  StyleSheet,
  ScrollView,
  View,
  Text,
  Image,
  TouchableOpacity,
  StatusBar
} from 'react-native';
import Slideshow from 'react-native-slideshow';
import c from './../colors';
import cs from './../commonStyles';
import Toolbar from './../components/Toolbar';
import CarouselItem from './../components/CarouselItem';
import RoomListItem from './../components/RoomListItem';
import {spotImageItems, availableRooms} from './../constants';
import API from "./../api";
import spinner from "./../../assets/loading.gif";

class CourtDetailsScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      court: this.props.navigation.getParam('item', null),
      details: null,
      isLoading: false,
      position: 0,
      interval: null
    };
  }
  componentDidMount() {
    this.didFocusListener = this.props.navigation.addListener(
      'didFocus',
      () => this._loadDetails()
    );
  }
  componentWillMount() {
    this._loadDetails();
    this.setState({
      interval: setInterval(() => {
        this.setState({
          position: this.state.position === spotImageItems.length ? 0 : this.state.position + 1
        });
      }, 5000)
    });
  }
  componentWillUnmount() {
    this.didFocusListener.remove();
    this._timeout && clearTimeout(this._timeout);
    clearInterval(this.state.interval);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={this.state.court.name ? this.state.court.name : 'Loading...'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderBody() {
    const { isLoading, details } = this.state;

    if (isLoading) {
      return (
        <View style={styles.detailsLoadingContainer}>
          <Image source={spinner} style={styles.loading} />
        </View>
      );
    }

    let sliders = [];
    details.photos.map((photo) => {
      sliders.push({
        title: photo.title,
        caption: photo.caption,
        url: photo.file
      });
    });

    return (
      <View style={cs.fl1}>
        <Slideshow
          dataSource={sliders}
          position={this.state.position}
          onPositionChanged={position => this.setState({ position })}
          indicatorSelectedColor={c.primary}
        />
        <View style={[cs.fl1, styles.roomListContainer]}>
          {this._renderRoomList()}
        </View>
      </View>
    );
  }
  _renderRoomList() {
    const { details } = this.state;
    const { rooms } = details;

    if (rooms.length > 0) {
      return (
        <View>
          {details.rooms.map((item, index) => (
            <RoomListItem
              key={`room-${index}`}
              price={details.price}
              item={item}
              navigation={this.props.navigation}
              overrideStyle={index != details.rooms.length - 1 && {marginBottom: 16}}
            />
          ))}
        </View>
      );
    }
  
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontFamily: 'VAGRounded_BT', fontSize: 14 }}>No room available</Text>
      </View>
    );
  }
  _renderCarouselItem = ({item}) => (
    <CarouselItem item={item} navigation={this.props.navigation} />
  );
  _renderFloatingButton() {
    return (
      <View style={styles.floatingButtonContainer}>
        <TouchableOpacity
          activeOpacity={.7}
          style={styles.floatingButton}
          onPress={() => this.props.navigation.navigate('CreateRoom', {courtId: this.state.court.id})}
        >
          <Text style={styles.floatingButtonText}>CREATE ROOM</Text>
        </TouchableOpacity>
      </View>
    );
  }
  _loadDetails() {
    this.setState({
      isLoading: true
    });

    const { court } = this.state;

    if (court) {

      API.get(`court/${court.id}/details`)
        .then(res => {
          if (res.data.success) {
            const { court } = res.data.success;
            
            this.setState({
              isLoading: false,
              details: court
            });
          }
        })
        .catch(error => {
          this.setState(
            {
              isLoading: false
            },
            () => {
              if (error.response) {
                if (error.response.data.message) {
                  return ToastAndroid.show(error.response.data.message, ToastAndroid.SHORT);
                } else {
                  return ToastAndroid.show(error.response.data.error.message, ToastAndroid.SHORT);
                }
              }
            }
          );
        });
    }
  }
  render() {
    return (
      <View style={cs.fl1}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        <ScrollView
          style={[cs.fl1, styles.container]}
          showsVerticalScrollIndicator={false}
        >
          {this._renderBody()}
        </ScrollView>
        {this._renderFloatingButton()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: c.white
  },
  detailsLoadingContainer: {
    paddingTop: 15,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  loading: {
    width: 32,
    height: 32
  },
  roomListContainer: {
    padding: 10,
    paddingBottom: 100
  },
  floatingButtonContainer: {
    position: 'absolute',
    bottom: 10,
    right: 10
  },
  floatingButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: c.primary_darker,
    padding: 10,
    width: 85,
    height: 85,
    borderRadius: 85,
    elevation: 2
  },
  floatingButtonText: {
    flex: 1,
    flexWrap: 'wrap',
    textAlign: 'center',
    fontFamily: 'VAGRounded_BT',
    fontSize: 14,
    color: c.white
  }
});

export default CourtDetailsScreen;