import React, {Component} from 'react';
import {
  StyleSheet,
  ScrollView,
  FlatList,
  View,
  StatusBar
} from 'react-native';
import c from './../colors';
import cs from './../commonStyles';
import {
  NUM_CT_GRID_COLUMNS,
  CT_ITEM_HEIGHT,
  CT_ITEM_OFFSET,
  CT_ITEM_MARGIN,
  sportCategories
} from './../constants';
import CategoryItem from './../components/CategoryItem';
import Toolbar from './../components/Toolbar';

class CategoryScreen extends Component {
  constructor(props) {
    super(props);
  }
  _renderToolbar() {
    return (
      <Toolbar
        title={'CATEGORIES'}
        canGoBack={true}
        _onBackPress={() => this.props.navigation.goBack()}
        _hasNotification
      />
    );
  }
  _renderCategoriesList() {
    return (
      <View style={styles.listSection}>
        <FlatList
          style={styles.list}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          data={sportCategories}
          keyExtractor={(item) => `category-${item.key}`}
          renderItem={this._renderCategoryItem}
          getItemLayout={this._getFlatListItemLayout}
          numColumns={NUM_CT_GRID_COLUMNS}
        />
      </View>
    );
  }
  _renderCategoryItem = ({item}) => (
    <CategoryItem item={item} navigation={this.props.navigation} />
  );
  _getFlatListItemLayout(data, index) {
    const itemHeight = CT_ITEM_HEIGHT * CT_ITEM_MARGIN;
    return {
      length: itemHeight,
      offset: itemHeight * index,
      index
    };
  }
  render() {
    return (
      <ScrollView
        style={[cs.fl1, { backgroundColor: c.white }]}
        showsVerticalScrollIndicator={false}
      >
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        {this._renderToolbar()}
        {this._renderCategoriesList()}
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  listSection: {
    flex: 1,
    paddingTop: 3,
    alignItems: 'center',
    justifyContent: 'center'
  },
  list: {
    padding: CT_ITEM_OFFSET
  }
});

export default CategoryScreen;