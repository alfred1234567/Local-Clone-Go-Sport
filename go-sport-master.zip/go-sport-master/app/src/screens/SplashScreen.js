import React, {Component} from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  StatusBar
} from 'react-native';
import {NavigationActions, StackActions} from 'react-navigation';
import c from './../colors';
import {name as appName} from './../../app.json';
const Logo = require('./../../assets/logo.jpg');

class SplashScreen extends Component {
  componentDidMount() {
    this._timeout = setTimeout(() => this._resetTo('Home'), 3000);
  }
  componentWillUnmount() {
    clearTimeout(this._timeout);
  }
  _resetTo(routeName) {
    const resetAction = StackActions.reset({
      index: 0,
      actions: [NavigationActions.navigate({ routeName })]
    });
    this.props.navigation.dispatch(resetAction);
  }
  render() {
    return (
      <View style={styles.container}>
        <StatusBar
          backgroundColor={c.soft_gray}
          barStyle='dark-content'
        />
        <Image
          resizeMode={'contain'}
          source={Logo}
          style={styles.logo}
        />
        <View style={styles.appNameWrapper}>
          <Text style={styles.appName}>{appName}</Text>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: c.white,
    alignItems: 'center',
    justifyContent: 'center'
  },
  logo: {
    width: 160,
    height: 160
  },
  appNameWrapper: {
    padding: 10,
    alignItems: 'center'
  },
  appName: {
    fontFamily: 'VAGRounded_BT',
    fontSize: 28,
    color: c.primary
  }
});

export default SplashScreen;