import React, {Component} from 'react';
import Routers from './routers';
console.disableYellowBox = true;

class App extends Component {
  render() {
    return <Routers/>;
  }
}

export default App;