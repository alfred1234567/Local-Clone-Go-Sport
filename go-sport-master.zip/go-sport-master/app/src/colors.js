export default {
  primary: '#d50000',
  primary_darker: '#b71c1c',
  white: '#fff',
  black: '#000',
  dark_gray: '#9e9e9e',
  soft_gray: '#f5f5f5',
  material_gray: '#e5e5e5',
  material_orange: '#ff8f00',
  material_green: '#00695c',
  material_purple: '#311b92',
  material_pink: '#880e4f',
  material_blue: '#03a9f4',
};