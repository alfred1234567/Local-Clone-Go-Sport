import { observable } from 'mobx';

class ObservableUserStore {
  @observable user = null;
  updateUser = (newUser) => {
    this.user = newUser;
  }
}

const observableUserStore = new ObservableUserStore();
export default observableUserStore;