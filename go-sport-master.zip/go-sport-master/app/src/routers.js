import {createStackNavigator} from 'react-navigation';
import ss from './screens/SplashScreen';
import hs from './screens/HomeScreen';
import ps from './screens/ProfileScreen';
import eps from './screens/EditProfileScreen';
import cs from './screens/CategoryScreen';
import cls from './screens/CategoryListScreen';
import sds from './screens/SpotDetailsScreen';
import crls from './screens/CourtListScreen';
import cds from './screens/CourtDetailsScreen';
import crs from './screens/CreateRoomScreen';
import jrs from './screens/JoinRoomScreen';
import rs from './screens/RegistrationScreen';
import fps from './screens/ForgotPasswordScreen';
import as from './screens/AboutUsScreen';

const navigationOptions = {
  header: null
};
const Routers = createStackNavigator({
  Splash: {
    screen: ss,
    navigationOptions: {...navigationOptions}
  },
  Home: {
    screen: hs,
    navigationOptions: {...navigationOptions}
  },
  Profile: {
    screen: ps,
    navigationOptions: {...navigationOptions}
  },
  EditProfile: {
    screen: eps,
    navigationOptions: {...navigationOptions}
  },
  Category: {
    screen: cs,
    navigationOptions: {...navigationOptions}
  },
  CategoryList: {
    screen: cls,
    navigationOptions: {...navigationOptions}
  },
  SpotDetails: {
    screen: sds,
    navigationOptions: {...navigationOptions}
  },
  CourtList: {
    screen: crls,
    navigationOptions: {...navigationOptions}
  },
  CourtDetails: {
    screen: cds,
    navigationOptions: {...navigationOptions}
  },
  CreateRoom: {
    screen: crs,
    navigationOptions: {...navigationOptions}
  },
  JoinRoom: {
    screen: jrs,
    navigationOptions: {...navigationOptions}
  },
  Registration: {
    screen: rs,
    navigationOptions: {...navigationOptions}
  },
  ForgotPassword: {
    screen: fps,
    navigationOptions: {...navigationOptions}
  },
  About: {
    screen: as,
    navigationOptions: {...navigationOptions}
  }
});

export default Routers;