// const API_BASE_URL = `http://192.168.0.25:8000/api/`;
const API_BASE_URL = `http://192.168.0.102:8000/api/`;

const menuItems = [
  {
    name: 'Home',
    icon: 'md-home',
    key: 'home'
  },
  {
    name: 'Profile',
    icon: 'md-person',
    key: 'profile'
  },
  {
    name: 'About Us',
    icon: 'md-information-circle',
    key: 'about_us'
  },
  {
    name: 'Contact Us',
    icon: 'ios-text',
    key: 'contact_us'
  }
];

const slideshowItems = [
  { url: require('./../assets/slideshow_img/1.jpg') },
  { url: require('./../assets/slideshow_img/2.jpg') },
  { url: require('./../assets/slideshow_img/3.jpg') },
  { url: require('./../assets/slideshow_img/4.jpg') },
  { url: require('./../assets/slideshow_img/5.jpg') },
];

const spotImageItems = [
  { title: 'Basket', caption: 'Lapangan Basket', url: require('./../assets/spot/1.jpg') },
  { title: 'Kolam Renang', caption: 'Kolam Renang', url: require('./../assets/spot/2.jpg') },
  { title: 'Kolam Renang', caption: 'Kolam Renang', url: require('./../assets/spot/3.jpg') },
  { title: 'Gym', caption: 'Gym', url: require('./../assets/spot/4.jpg') },
];

const NUM_CT_GRID_COLUMNS = 3;
const CT_ITEM_HEIGHT = 88;
const CT_ITEM_OFFSET = 10;
const CT_ITEM_MARGIN = CT_ITEM_OFFSET * 2;

const sportCategories = [
  {
    id: 1,
    name: "Basketball",
    key: "basketball",
    icon: require("./../assets/categories/basketball.png")
  },
  {
    id: 2,
    name: "Futsal",
    key: "futsal",
    icon: require("./../assets/categories/futsal.png")
  },
  {
    id: 3,
    name: "Badminton",
    key: "badminton",
    icon: require("./../assets/categories/badminton.png")
  },
  {
    id: 4,
    name: "Swimming",
    key: "swimming",
    icon: require("./../assets/categories/swimming.png")
  },
  {
    id: 5,
    name: "Volley",
    key: "volley",
    icon: require("./../assets/categories/volleyball.png")
  }
];

const categoryList = [
  {
    id: 1,
    name: "Tangkas Sport Centre",
    address: "Tahap III, Jl. Tanjung Duren Komplek Greenville Blok Q, RT.11/RW.9, Duri Kepa, Kb. Jeruk, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11510",
    price: 100000,
    ratings: 4.2,
    thumbnail: require("./../assets/thumbnail_img/tangkas.jpg")
  },
  {
    id: 2,
    name: "Smash Badminton Hall",
    address: "RT.13/RW.7, Duri Kosambi, Cengkareng, West Jakarta City, Jakarta 11750",
    price: 75000,
    ratings: 4.5,
    thumbnail: require("./../assets/thumbnail_img/smash.jpg")
  },
  {
    id: 3,
    name: "Candra Wijaya Int'l Badminton Club",
    address: "Jalan Jelupang Raya No.15, Serpong Utara, Jelupang, Serpong Utara, Kota Tangerang Selatan, Banten 15323",
    price: 90000,
    ratings: 4.7,
    thumbnail: require("./../assets/thumbnail_img/cwibc.jpg")
  },
  {
    id: 4,
    name: "Osdara Badminton Hall",
    address: "Kenanga, Cipondoh, Tangerang City, Banten 15148",
    price: 65000,
    ratings: 4.3,
    thumbnail: require("./../assets/thumbnail_img/osdara.png")
  },
  {
    id: 5,
    name: "Garuda badminton",
    address: "Jl. Perdana Kusuma Blok Qq No.248 B, RT.1/RW.4, Wijaya Kusuma, Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11460",
    price: 87000,
    ratings: 4.4,
    thumbnail: require("./../assets/thumbnail_img/garuda.jpg")
  }
];

const courtList = [
  {
    id: 1,
    name: "Lapangan Kayu 1",
    point: 10,
    fare: 65000,
    photoThumb: require("./../assets/thumbnail_img/garuda.jpg")
  },
  {
    id: 2,
    name: "Lapangan Kayu 2",
    point: 10,
    fare: 65000,
    photoThumb: require("./../assets/thumbnail_img/osdara.png")
  },
  {
    id: 3,
    name: "Lapangan Karpet 1",
    point: 20,
    fare: 77000,
    photoThumb: require("./../assets/thumbnail_img/cwibc.jpg")
  }
];

const availableRooms = [
  {
    id: 1,
    dateTime: new Date(),
    duration: 2, // in hours
    slot: 5,
    fare: 25000,
    paidOff: true
  },
  {
    id: 2,
    dateTime: new Date(),
    duration: 1, // in hours
    slot: 10,
    fare: 20000,
    paidOff: false
  },
  {
    id: 3,
    dateTime: new Date(),
    duration: 3, // in hours
    slot: 10,
    fare: 75000,
    paidOff: false
  }
];

export {
  API_BASE_URL,

  menuItems,
  slideshowItems,
  spotImageItems,

  NUM_CT_GRID_COLUMNS,
  CT_ITEM_HEIGHT,
  CT_ITEM_OFFSET,
  CT_ITEM_MARGIN,

  sportCategories,
  categoryList,
  courtList,
  availableRooms
};