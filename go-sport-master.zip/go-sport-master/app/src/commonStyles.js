import {StyleSheet} from 'react-native';
import c from './colors';

export default StyleSheet.create({
  fl05: {
    flex: .5
  },
  fl1: {
    flex: 1
  },
  fl2: {
    flex: 2
  },
  fl3: {
    flex: 3
  },
  fl4: {
    flex: 4
  },
  fl5: {
    flex: 5
  },
  transparent: {
    backgroundColor: 'transparent'
  },
  row: {
    flexDirection: 'row'
  },
  col: {
    flexDirection: 'column'
  },

  boxForm: {
    backgroundColor: c.white,
    paddingHorizontal: 30,
    paddingVertical: 20,
    marginBottom: 10,
    elevation: 2
  },
  formLabel: {
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 14,
    fontWeight: '500',
    color: c.black
  },
  formGroup: {
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderBottomWidth: 1,
    borderBottomColor: c.dark_gray
  },
  fieldIcon: {
    paddingVertical: 5,
    paddingRight: 5
  },
  fieldInput: {
    flex: 1,
    height: 40,
    paddingVertical: 10,
    backgroundColor: 'transparent',
    color: c.black
  },
  formButton: {
    marginTop: 15,
    paddingVertical: 14,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 1
  },
  formButtonLabel: {
    color: c.white,
    fontFamily: 'VAGRoundedBT-Regular',
    fontSize: 14
  }
});